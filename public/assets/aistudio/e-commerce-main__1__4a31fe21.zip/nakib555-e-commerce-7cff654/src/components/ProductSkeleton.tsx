import React from 'react';

export function ProductSkeleton({ className = '' }: { className?: string }) {
  return (
    <div className={`bg-white dark:bg-[#121316] rounded-lg sm:rounded-xl overflow-hidden border border-stone-200/80 dark:border-neutral-800 flex flex-col h-full ${className}`}>
      <div className="relative aspect-square shimmer w-full"></div>
      <div className="p-3 flex flex-col flex-1 justify-between gap-2">
        <div>
          <div className="h-3 shimmer rounded w-1/3 mb-1.5"></div>
          <div className="h-3.5 shimmer rounded w-full mb-1"></div>
          <div className="h-3.5 shimmer rounded w-2/3"></div>
        </div>
        <div className="flex items-center justify-between pt-2 border-t border-stone-100 dark:border-neutral-800">
          <div className="h-4 shimmer rounded w-16"></div>
          <div className="w-8 h-8 rounded-md shimmer shrink-0"></div>
        </div>
      </div>
    </div>
  );
}
