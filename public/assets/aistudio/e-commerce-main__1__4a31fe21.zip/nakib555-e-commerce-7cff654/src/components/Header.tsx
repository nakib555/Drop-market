import React, { useState, useEffect } from 'react';
import { ShoppingBag, Search, User, Heart, ShoppingCart, Menu, ChevronDown, MapPin, X, Moon, Sun } from 'lucide-react';
import { motion } from 'motion/react';
import { SEASONAL_THEMES } from '../theme';

interface HeaderProps {
  activeTab?: string;
  onTabChange?: (tab: string) => void;
  cartCount?: number;
  onCartClick?: () => void;
  isLoggedIn?: boolean;
  user?: { name: string; email: string; phone: string; address: string } | null;
  onLoginClick?: () => void;
  currentSeason?: string;
  onSeasonChange?: (season: string) => void;
}

export function Header({ 
  activeTab = 'home', 
  onTabChange, 
  cartCount = 2, 
  onCartClick,
  isLoggedIn = false,
  user = null,
  onLoginClick,
  currentSeason = 'default',
  onSeasonChange
}: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState('ঢাকা, বাংলাদেশ');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isMobileSearchOpen, setIsMobileSearchOpen] = useState(false);

  useEffect(() => {
    if (document.documentElement.classList.contains('dark')) {
      setIsDarkMode(true);
    }
    
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 24);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  return (
    <header className="w-full bg-white/95 dark:bg-[#121315]/95 backdrop-blur-md flex flex-col z-50 border-b border-stone-200/80 dark:border-neutral-800 sticky top-0 transition-all duration-200">
      {/* Slim Editorial Utility Strip (Desktop) - 32px (h-8 = 4 * 8pt) */}
      <div className="bg-brand-dark text-stone-100 text-xs h-8 px-4 hidden md:flex items-center border-b border-white/10">
        <div className="max-w-7xl mx-auto w-full px-0 sm:px-2 lg:px-4 flex items-center justify-between">
          <div className="flex items-center gap-3 text-stone-200">
            <button
              onClick={() => setIsLocationModalOpen(true)}
              className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer"
            >
              <MapPin size={12} className="text-emerald-400" />
              <span>ডেলিভারি এরিয়া: <strong className="font-semibold text-white">{selectedLocation}</strong></span>
              <ChevronDown size={12} className="opacity-70" />
            </button>
            <span aria-hidden="true" className="text-white/25">·</span>
            <span className="tabular-nums">৳১,৪৯৯+ অর্ডারে ফ্রি ডেলিভারি</span>
          </div>

          <div className="flex items-center gap-4 text-stone-200">
            <button onClick={() => onTabChange?.('orders')} className="hover:text-white transition-colors cursor-pointer">
              অর্ডার ট্র্যাকিং
            </button>
            <span aria-hidden="true" className="text-white/25">·</span>
            <button onClick={() => onTabChange?.('more')} className="hover:text-white transition-colors cursor-pointer">
              গ্রাহক সেবা
            </button>
            <span aria-hidden="true" className="text-white/25">·</span>
            <button 
              onClick={() => window.dispatchEvent(new CustomEvent('show-pwa-install'))}
              className="hover:text-white transition-colors font-medium text-emerald-300 cursor-pointer"
            >
              ওয়েব অ্যাপ ইনস্টল
            </button>
          </div>
        </div>
      </div>

      {/* Main Header Row - 48px (h-12) mobile, 56px (h-14) desktop */}
      <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 h-12 md:h-14 flex items-center justify-between gap-4 lg:gap-6">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => onTabChange?.('more')}
            aria-label="Open menu"
            className="md:hidden text-stone-800 dark:text-stone-200 w-8 h-8 -ml-1 rounded-lg hover:bg-stone-100 dark:hover:bg-neutral-800 flex items-center justify-center"
          >
            <Menu className="h-4 w-4" strokeWidth={1.75} />
          </button>
          <a 
            href="#home" 
            onClick={(e) => { e.preventDefault(); onTabChange?.('home'); }}
            className="flex items-center gap-2 text-base md:text-xl font-heading font-semibold text-stone-900 dark:text-white tracking-tight whitespace-nowrap"
          >
            <span className="w-7 h-7 md:w-8 md:h-8 rounded-lg bg-brand-emerald text-white flex items-center justify-center shadow-2xs">
              <ShoppingBag className="h-4 w-4" strokeWidth={2} />
            </span>
            <span>Deshi<span className="text-brand-emerald dark:text-emerald-400">Mart</span></span>
          </a>
        </div>

        {/* Zone 2: Integrated Search Bar (Desktop) - 36px (h-9) */}
        <div className="flex-1 max-w-md hidden md:flex items-center relative">
          <Search size={14} className="absolute left-3 text-stone-400 pointer-events-none" />
          <input 
            type="text" 
            placeholder="পণ্য, ক্যাটাগরি বা ব্র্যান্ড খুঁজুন..." 
            aria-label="পণ্য খুঁজুন"
            className="w-full h-9 border border-stone-200 dark:border-neutral-800 bg-stone-50/80 dark:bg-neutral-900 text-stone-900 dark:text-white text-sm rounded-lg pl-8 pr-16 focus:outline-none focus:bg-white dark:focus:bg-neutral-900 focus:border-brand-emerald transition-colors placeholder:text-stone-400"
          />
          <button className="absolute right-1 top-1 bottom-1 bg-brand-emerald hover:bg-brand-dark text-white text-xs font-medium px-3 rounded-md transition-colors cursor-pointer whitespace-nowrap">
            খুঁজুন
          </button>
        </div>

        {/* Zone 3: Primary Controls & Actions (8pt grid: h-8 / h-9 controls, gap-2) */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Seasonal Campaign Selector */}
          <div className="relative flex items-center">
            <select 
              value={currentSeason}
              onChange={(e) => onSeasonChange?.(e.target.value)}
              aria-label="সিজনাল থিম নির্বাচন করুন"
              className="appearance-none h-8 bg-stone-100/80 dark:bg-neutral-800/90 text-stone-700 dark:text-stone-200 border border-stone-200/80 dark:border-neutral-700 rounded-md pl-2.5 pr-6 text-xs font-medium cursor-pointer focus:outline-none focus:border-brand-emerald transition-colors hover:bg-stone-200/60 dark:hover:bg-neutral-700"
            >
              {SEASONAL_THEMES.map((theme) => (
                <option key={theme.key} value={theme.key}>
                  {theme.name}
                </option>
              ))}
            </select>
            <ChevronDown size={12} className="absolute right-2 top-1/2 -translate-y-1/2 text-stone-500 pointer-events-none" />
          </div>

          <button 
            onClick={toggleDarkMode}
            className="w-8 h-8 rounded-md text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-neutral-800 hover:text-brand-emerald transition-colors flex items-center justify-center cursor-pointer"
            aria-label="ডার্ক মোড পরিবর্তন করুন"
          >
            {isDarkMode ? (
              <Sun className="h-4 w-4" strokeWidth={1.75} />
            ) : (
              <Moon className="h-4 w-4" strokeWidth={1.75} />
            )}
          </button>
          
          <button
            onClick={() => setIsMobileSearchOpen(!isMobileSearchOpen)}
            aria-label="অনুসন্ধান খুলুন"
            className="md:hidden w-8 h-8 rounded-md text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-neutral-800 flex items-center justify-center"
          >
            <Search className="h-4 w-4" strokeWidth={1.75} />
          </button>
          
          <button 
            onClick={isLoggedIn ? () => onTabChange?.('profile') : onLoginClick} 
            className="h-8 flex items-center gap-1.5 px-2.5 rounded-md text-stone-700 dark:text-stone-200 hover:bg-stone-100 dark:hover:bg-neutral-800 hover:text-brand-emerald transition-colors cursor-pointer whitespace-nowrap"
          >
            <User className={`h-4 w-4 ${isLoggedIn ? "text-brand-emerald" : ""}`} strokeWidth={1.75} />
            <span className="text-sm font-medium hidden lg:inline">{isLoggedIn ? (user?.name || 'প্রোফাইল') : 'লগইন'}</span>
          </button>
          
          <button
            onClick={() => onTabChange?.('profile')}
            className="hidden md:flex h-8 items-center gap-1.5 px-2.5 rounded-md text-stone-700 dark:text-stone-200 hover:bg-stone-100 dark:hover:bg-neutral-800 hover:text-brand-emerald transition-colors cursor-pointer whitespace-nowrap"
          >
            <Heart className="h-4 w-4" strokeWidth={1.75} />
            <span className="text-sm font-medium hidden xl:inline">উইশলিস্ট</span>
          </button>
          
          <button
            onClick={onCartClick || (() => onTabChange?.('profile'))}
            aria-label="শপিং কার্ট"
            className="h-8 sm:h-9 flex items-center gap-2 bg-stone-900 dark:bg-brand-emerald hover:bg-brand-emerald dark:hover:bg-emerald-700 text-white px-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap shadow-2xs"
          >
            <ShoppingCart className="h-4 w-4" strokeWidth={1.85} />
            <span className="text-xs sm:text-sm font-medium hidden sm:inline">কার্ট</span>
            <span className="bg-white/20 text-white text-2xs font-semibold tabular-nums px-1.5 py-0.5 rounded leading-none">
              {cartCount}
            </span>
          </button>
        </div>
      </div>

      {/* Mobile Search Bar - Animated (8pt grid) */}
      <div 
        className={`md:hidden px-4 transition-all duration-200 ease-out overflow-hidden bg-white dark:bg-[#121315] ${
          isMobileSearchOpen ? 'max-h-14 opacity-100 pb-2 border-b border-stone-100 dark:border-neutral-800' : 'max-h-0 opacity-0 pb-0 border-transparent'
        }`}
      >
        <div className="flex items-center relative">
          <input 
            type="text" 
            placeholder="আপনি কী খুঁজছেন?" 
            className="w-full h-9 border border-stone-200 dark:border-neutral-700 bg-stone-50 dark:bg-neutral-900 dark:text-white rounded-lg pl-3 pr-10 text-sm focus:outline-none focus:border-brand-emerald"
          />
          <button className="absolute right-1 top-1 bottom-1 text-white bg-brand-emerald px-2.5 rounded-md hover:bg-brand-dark transition-colors flex items-center justify-center">
            <Search size={14} strokeWidth={2} />
          </button>
        </div>
      </div>

      {/* Mobile Location Selector */}
      <div 
        className={`px-4 md:hidden flex flex-col transition-all duration-200 bg-white dark:bg-[#121315] ${isScrolled || isMobileSearchOpen ? '' : 'pb-2'}`}
      >
        <div 
          onClick={() => setIsLocationModalOpen(true)}
          className={`flex items-center gap-1.5 text-xs text-stone-600 dark:text-stone-400 border-stone-100 dark:border-neutral-800 transition-all duration-200 overflow-hidden cursor-pointer ${isScrolled || isMobileSearchOpen ? 'max-h-0 opacity-0 pb-0 border-transparent' : 'max-h-8 opacity-100 pb-1 border-b'}`}>
          <MapPin size={12} className="text-brand-emerald shrink-0" />
          <span className="truncate font-medium">ডেলিভারি: {selectedLocation}</span>
          <ChevronDown size={12} className="text-stone-400 shrink-0" />
        </div>
      </div>

      {/* Primary Navigation Row (Desktop) - 40px (h-10 = 5 * 8pt) */}
      <div className="border-t border-stone-200/60 dark:border-neutral-800/80 hidden md:block bg-stone-50/40 dark:bg-[#121315]">
        <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 h-10 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <button
              onClick={() => onTabChange?.('categories')}
              className="flex items-center gap-1.5 text-sm font-semibold text-stone-900 dark:text-stone-100 hover:text-brand-emerald dark:hover:text-emerald-400 transition-colors cursor-pointer whitespace-nowrap"
            >
              <Menu size={15} className="text-brand-emerald" />
              <span>সকল ক্যাটাগরি</span>
            </button>
            <span aria-hidden="true" className="h-4 w-px bg-stone-200 dark:bg-neutral-800" />
            <nav className="flex items-center gap-6" aria-label="প্রধান নেভিগেশন">
              {[
                { id: 'home', label: 'হোম' },
                { id: 'categories', label: 'ক্যাটাগরি সমূহ' },
                { id: 'orders', label: 'আমার অর্ডার' },
                { id: 'profile', label: 'আমার প্রোফাইল' },
                { id: 'more', label: 'যোগাযোগ ও সাহায্য' }
              ].map((tab) => {
                const isActive = activeTab === tab.id;
                return (
                  <button 
                    key={tab.id}
                    onClick={() => onTabChange?.(tab.id)}
                    className={`relative font-medium transition-colors py-1 text-sm cursor-pointer whitespace-nowrap ${
                      isActive 
                        ? 'text-brand-emerald dark:text-emerald-400 font-semibold' 
                        : 'text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white'
                    }`}
                  >
                    <span className="relative z-10">{tab.label}</span>
                    {isActive && (
                      <motion.span 
                        layoutId="desktopActiveIndicator"
                        className="absolute -bottom-2 left-0 right-0 h-0.5 bg-brand-emerald dark:bg-emerald-400 rounded-full"
                        transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                      />
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          <a
            href="#flash-sale"
            onClick={(e) => {
              e.preventDefault();
              onTabChange?.('home');
              setTimeout(() => {
                document.getElementById('flash-sale')?.scrollIntoView({ behavior: 'smooth' });
              }, 100);
            }}
            className="text-xs font-semibold text-brand-emerald dark:text-emerald-400 hover:text-brand-dark border border-brand-emerald/25 dark:border-emerald-500/30 bg-brand-emerald/5 px-3 py-1 rounded-md transition-colors whitespace-nowrap"
          >
            ফ্ল্যাশ সেল অফার →
          </a>
        </div>
      </div>

      {/* Location Modal (8pt grid) */}
      {isLocationModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-[#141518] rounded-xl w-full max-w-sm overflow-hidden flex flex-col shadow-xl border border-stone-200/80 dark:border-neutral-800">
            <div className="flex items-center justify-between px-4 py-3 border-b border-stone-100 dark:border-neutral-800">
              <h3 className="font-heading font-semibold text-stone-900 dark:text-white text-base">ডেলিভারি অঞ্চল নির্বাচন করুন</h3>
              <button
                onClick={() => setIsLocationModalOpen(false)}
                aria-label="বন্ধ করুন"
                className="text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 transition-colors p-1 rounded-md hover:bg-stone-100 dark:hover:bg-neutral-800 cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>
            <div className="p-4 flex flex-col gap-2 max-h-[60vh] overflow-y-auto hide-scrollbar">
              {['ঢাকা, বাংলাদেশ', 'চট্টগ্রাম, বাংলাদেশ', 'সিলেট, বাংলাদেশ', 'রাজশাহী, বাংলাদেশ', 'খুলনা, বাংলাদেশ'].map((loc) => (
                <button 
                  key={loc}
                  onClick={() => {
                    setSelectedLocation(loc);
                    setIsLocationModalOpen(false);
                  }}
                  className={`flex items-center gap-2.5 px-3 py-2 rounded-lg border text-left transition-colors cursor-pointer ${
                    selectedLocation === loc
                      ? 'border-brand-emerald bg-brand-emerald/5 dark:bg-brand-emerald/15 text-brand-emerald dark:text-emerald-400 font-semibold'
                      : 'border-stone-200 dark:border-neutral-800 hover:border-stone-300 dark:hover:border-neutral-700 text-stone-700 dark:text-stone-300'
                  }`}
                >
                  <MapPin size={15} className={selectedLocation === loc ? 'text-brand-emerald dark:text-emerald-400' : 'text-stone-400'} />
                  <span className="text-sm">{loc}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
