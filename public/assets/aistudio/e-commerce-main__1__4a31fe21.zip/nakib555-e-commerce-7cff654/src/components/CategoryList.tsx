import React from 'react';
import { categories } from '../data';
import { Grid, ArrowRight } from 'lucide-react';
import { TYPOGRAPHY_TOKENS } from '../theme';

export function CategoryList() {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
      <div className="flex items-end justify-between mb-3 sm:mb-4">
        <div>
          <p className="text-xs font-medium text-brand-emerald dark:text-emerald-400 mb-0.5">ক্যাটাগরি নির্বাচন</p>
          <h2 className={TYPOGRAPHY_TOKENS.sectionTitle}>জনপ্রিয় বিভাগসমূহ</h2>
        </div>
        <a
          href="#categories"
          onClick={(e) => e.preventDefault()}
          className="text-xs font-semibold text-stone-700 dark:text-stone-300 hover:text-brand-emerald dark:hover:text-emerald-400 flex items-center gap-1 transition-colors whitespace-nowrap"
        >
          <span>সব দেখুন</span>
          <ArrowRight size={13} />
        </a>
      </div>

      {/* Mobile Grid View (8pt grid: gap-2, w-14 h-14 = 56px, rounded-lg) */}
      <div className="grid grid-cols-4 gap-2 sm:gap-3 md:hidden">
        {categories.slice(0, 7).map((category) => (
          <a
            key={category.id}
            href={`#category-${category.id}`}
            onClick={(e) => e.preventDefault()}
            className="flex flex-col items-center gap-1 group"
          >
            <div className="w-14 h-14 rounded-lg overflow-hidden border border-stone-200/80 dark:border-neutral-800 bg-white dark:bg-[#121316] p-1 transition-colors duration-150 group-hover:border-brand-emerald">
              <img 
                src={category.image} 
                alt={category.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover rounded-md group-hover:scale-105 transition-transform duration-300"
              />
            </div>
            <span className="text-xs text-center font-medium text-stone-800 dark:text-stone-200 leading-4 group-hover:text-brand-emerald transition-colors">
              {category.name}
            </span>
          </a>
        ))}
        <a
          href="#all-categories"
          onClick={(e) => e.preventDefault()}
          className="flex flex-col items-center gap-1 group"
        >
          <div className="w-14 h-14 rounded-lg bg-white dark:bg-[#121316] border border-stone-200/80 dark:border-neutral-800 flex items-center justify-center text-stone-600 dark:text-stone-300 group-hover:border-brand-emerald group-hover:text-brand-emerald transition-colors duration-150">
            <Grid size={18} strokeWidth={1.75} />
          </div>
          <span className="text-xs text-center font-medium text-stone-800 dark:text-stone-200 leading-4">
            সব ক্যাটাগরি
          </span>
        </a>
      </div>

      {/* Desktop Horizontal Card Strip (8pt grid: gap-3, p-3, rounded-lg, w-12 h-12) */}
      <div className="hidden md:grid md:grid-cols-4 lg:grid-cols-8 gap-3">
        {categories.map((category) => (
          <a
            key={category.id}
            href={`#category-${category.id}`}
            onClick={(e) => e.preventDefault()}
            className="flex flex-col items-center p-3 rounded-lg bg-white dark:bg-[#121316] border border-stone-200/80 dark:border-neutral-800 hover:border-brand-emerald/50 dark:hover:border-emerald-500/40 transition-colors duration-150 group"
          >
            <div className="w-12 h-12 rounded-lg overflow-hidden mb-2 bg-stone-100 dark:bg-neutral-900 border border-stone-200/60 dark:border-neutral-800">
              <img 
                src={category.image} 
                alt={category.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
            </div>
            <span className="text-xs text-center font-medium text-stone-800 dark:text-stone-200 group-hover:text-brand-emerald dark:group-hover:text-emerald-400 transition-colors truncate w-full">
              {category.name}
            </span>
          </a>
        ))}
        
        <a
          href="#all-categories"
          onClick={(e) => e.preventDefault()}
          className="flex flex-col items-center justify-center p-3 rounded-lg bg-stone-100/70 dark:bg-[#121316] border border-stone-200/80 dark:border-neutral-800 hover:border-brand-emerald/50 transition-colors duration-150 group"
        >
          <div className="w-12 h-12 rounded-lg bg-white dark:bg-neutral-900 flex items-center justify-center mb-2 text-stone-600 dark:text-stone-300 group-hover:text-brand-emerald border border-stone-200/60 dark:border-neutral-800 transition-colors">
            <Grid size={18} strokeWidth={1.75} />
          </div>
          <span className="text-xs text-center font-medium text-stone-800 dark:text-stone-200 group-hover:text-brand-emerald transition-colors">
            সব ক্যাটাগরি
          </span>
        </a>
      </div>
    </section>
  );
}
