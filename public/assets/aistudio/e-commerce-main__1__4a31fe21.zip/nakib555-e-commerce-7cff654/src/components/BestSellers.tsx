import React from 'react';
import { ProductCard } from './ProductCard';
import { bestSellerProducts } from '../data';
import { ArrowRight, ShoppingCart, Star } from 'lucide-react';
import { Product } from '../types';
import { TYPOGRAPHY_TOKENS } from '../theme';

const ProductListCard: React.FC<{ 
  product: Product; 
  onProductClick?: (product: Product) => void;
  onAddToCart?: (product: Product, quantity: number) => void;
}> = ({ product, onProductClick, onAddToCart }) => {
  return (
    <article 
      onClick={() => onProductClick?.(product)}
      className="bg-white dark:bg-[#121316] rounded-lg overflow-hidden border border-stone-200/80 dark:border-neutral-800 flex items-center p-2 gap-3 relative cursor-pointer hover:border-stone-300 dark:hover:border-neutral-700 transition-colors duration-150"
    >
      {/* Image (64px = 8 * 8pt) */}
      <div className="w-16 h-16 shrink-0 rounded-md overflow-hidden bg-[#F5F4F0] dark:bg-[#18191C] flex items-center justify-center relative">
        <img 
          src={product.image} 
          alt={product.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover"
        />
        {product.discount && (
          <span className="absolute top-1 left-1 bg-stone-900/85 text-white text-2xs font-semibold tabular-nums px-1.5 py-0.5 rounded">
            -{product.discount}%
          </span>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0 flex flex-col justify-center py-0.5">
        <div className="flex items-center gap-1 text-xs text-stone-500 dark:text-stone-400 mb-0.5 tabular-nums">
          <Star size={11} className="fill-amber-500 text-amber-500 shrink-0" />
          <span className="font-medium text-stone-700 dark:text-stone-300">{product.rating}</span>
          <span aria-hidden="true">·</span>
          <span>{product.reviews} রিভিউ</span>
        </div>

        <h3 className={`${TYPOGRAPHY_TOKENS.cardTitle} line-clamp-1 mb-1`}>
          {product.name}
        </h3>
        
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-baseline gap-1.5 tabular-nums">
            <span className={TYPOGRAPHY_TOKENS.price}>৳{product.price.toLocaleString('en-IN')}</span>
            {product.oldPrice && (
              <span className="text-xs text-stone-400 line-through">৳{product.oldPrice.toLocaleString('en-IN')}</span>
            )}
          </div>
          
          <button 
            type="button"
            aria-label={`${product.name} কার্টে যোগ করুন`}
            onClick={(e) => {
              e.stopPropagation();
              if (onAddToCart) onAddToCart(product, 1);
            }}
            className="w-8 h-8 rounded-md bg-stone-100 dark:bg-neutral-800 border border-stone-200/70 dark:border-neutral-700 flex items-center justify-center text-stone-700 dark:text-stone-200 hover:bg-brand-emerald hover:text-white hover:border-brand-emerald transition-colors shrink-0 cursor-pointer"
          >
            <ShoppingCart size={13} />
          </button>
        </div>
      </div>
    </article>
  );
};

interface BestSellersProps {
  onProductClick?: (product: Product) => void;
  onAddToCart?: (product: Product, quantity: number) => void;
}

export function BestSellers({ onProductClick, onAddToCart }: BestSellersProps) {
  return (
    <section id="featured-collection" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
      <div className="flex items-end justify-between mb-3 sm:mb-4">
        <div>
          <p className="text-xs font-medium text-brand-emerald dark:text-emerald-400 mb-0.5">ক্রেতাদের পছন্দ</p>
          <h2 className={TYPOGRAPHY_TOKENS.sectionTitle}>সেরা বিক্রিত পণ্যসমূহ</h2>
        </div>
        
        <a
          href="#all-best-sellers"
          onClick={(e) => e.preventDefault()}
          className="text-xs font-semibold text-stone-700 dark:text-stone-300 hover:text-brand-emerald dark:hover:text-emerald-400 flex items-center gap-1 transition-colors whitespace-nowrap"
        >
          <span>সব দেখুন</span>
          <ArrowRight size={13} />
        </a>
      </div>

      {/* Mobile List View (8pt grid: gap-2) */}
      <div className="flex flex-col gap-2 md:hidden">
        {bestSellerProducts.slice(0, 4).map(product => (
          <ProductListCard 
            key={product.id} 
            product={product} 
            onProductClick={onProductClick}
            onAddToCart={onAddToCart}
          />
        ))}
      </div>

      {/* Desktop Grid View (3-column tablet, 6-column xl, gap-3) */}
      <div className="hidden md:grid grid-cols-3 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        {bestSellerProducts.slice(0, 6).map(product => (
          <ProductCard 
            key={product.id} 
            product={product} 
            onProductClick={onProductClick}
            onAddToCart={onAddToCart}
          />
        ))}
      </div>
    </section>
  );
}
