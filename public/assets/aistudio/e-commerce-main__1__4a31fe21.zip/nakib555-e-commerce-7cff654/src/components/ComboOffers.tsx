import React, { useState } from 'react';
import { ShoppingCart, Star, Check } from 'lucide-react';
import { Product } from '../types';
import { TYPOGRAPHY_TOKENS } from '../theme';

interface ComboOffersProps {
  onProductClick?: (product: Product) => void;
  onAddToCart?: (product: Product, quantity: number) => void;
}

export const comboProducts: Product[] = [
  {
    id: 'combo1',
    name: 'উৎসবের খুশি পাঞ্জাবি ও আতর কম্বো',
    price: 1890,
    oldPrice: 2450,
    discount: 22,
    image: 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&q=80&w=400&h=500',
    rating: 4.9,
    reviews: 142
  },
  {
    id: 'combo2',
    name: 'ঐতিহ্যবাহী জামদানী শাড়ি ও চুড়ি কম্বো',
    price: 3450,
    oldPrice: 4200,
    discount: 17,
    image: 'https://images.unsplash.com/photo-1610030469668-93535c17b6b3?auto=format&fit=crop&q=80&w=400&h=500',
    rating: 4.8,
    reviews: 98
  },
  {
    id: 'combo3',
    name: 'প্রিমিয়াম সুন্দরবনের মধু ও খাঁটি ঘি কম্বো',
    price: 1650,
    oldPrice: 1990,
    discount: 17,
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80&w=400&h=500',
    rating: 4.7,
    reviews: 74
  }
];

const comboDetails: Record<string, string[]> = {
  combo1: ['প্রিমিয়াম কটন পাঞ্জাবি', 'প্রাকৃতিক খাস আতর', 'উপহার বক্স'],
  combo2: ['আদি তাঁতের জামদানী শাড়ি', 'রেশমি কাঁচের চুড়ি সেট', 'ম্যাচিং ব্লাউজ পিস'],
  combo3: ['সুন্দরবনের খাঁটি মধু ৫০০ গ্রাম', 'গাওয়া খাঁটি ঘি ৫০০ গ্রাম', 'ঐতিহ্যবাহী মাটির পাত্র']
};

export function ComboOffers({ onProductClick, onAddToCart }: ComboOffersProps) {
  const [addedItems, setAddedItems] = useState<Record<string, boolean>>({});

  const handleCartAction = (e: React.MouseEvent, product: Product) => {
    e.stopPropagation();
    if (onAddToCart) {
      onAddToCart(product, 1);
      setAddedItems(prev => ({ ...prev, [product.id]: true }));
      setTimeout(() => {
        setAddedItems(prev => ({ ...prev, [product.id]: false }));
      }, 2000);
    }
  };

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-3 sm:mb-4 gap-2">
        <div>
          <p className="text-xs font-medium text-brand-emerald dark:text-emerald-400 mb-0.5">বিশেষ সাশ্রয়ী বান্ডেল</p>
          <h2 className={TYPOGRAPHY_TOKENS.sectionTitle}>কিউরেটেড কম্বো প্যাকসমূহ</h2>
          <p className="text-xs sm:text-sm text-stone-500 dark:text-stone-400 mt-0.5">
            একত্রে কিনুন এবং বিশেষ উপহার বক্সের সাথে অতিরিক্ত সাশ্রয় উপভোগ করুন
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 sm:gap-4">
        {comboProducts.map((product) => {
          const details = comboDetails[product.id] || [];
          const isAdded = addedItems[product.id];

          return (
            <article
              key={product.id}
              onClick={() => onProductClick?.(product)}
              className="group bg-white dark:bg-[#121316] rounded-xl border border-stone-200/80 dark:border-neutral-800 hover:border-stone-300 dark:hover:border-neutral-700 transition-colors duration-150 flex flex-col overflow-hidden cursor-pointer"
            >
              {/* Image Section */}
              <div className="relative aspect-[16/10] overflow-hidden bg-[#F5F4F0] dark:bg-[#18191C]">
                <img
                  src={product.image}
                  alt={product.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
                />
                {product.discount && (
                  <div className="absolute top-2 left-2 bg-stone-900/90 text-white text-2xs font-semibold tabular-nums px-2 py-0.5 rounded">
                    -{product.discount}% ছাড়
                  </div>
                )}
              </div>

              {/* Info Section (8pt grid: p-3 sm:p-4) */}
              <div className="p-3 sm:p-4 flex-1 flex flex-col">
                <div className="flex items-center gap-1 text-xs text-stone-500 dark:text-stone-400 mb-1 tabular-nums">
                  <Star size={11} className="text-amber-500 fill-amber-500" />
                  <span className="font-medium text-stone-700 dark:text-stone-300">{product.rating}</span>
                  <span aria-hidden="true">·</span>
                  <span>{product.reviews} রিভিউ</span>
                </div>

                <h3 className="font-sans font-semibold text-sm sm:text-base text-stone-900 dark:text-stone-100 leading-5 group-hover:text-brand-emerald dark:group-hover:text-emerald-400 transition-colors mb-2">
                  {product.name}
                </h3>

                {/* Included Items List */}
                <div className="border-t border-stone-100 dark:border-neutral-800 pt-2 mb-3 flex-1">
                  <span className="text-xs text-stone-500 dark:text-stone-400 font-medium block mb-1">প্যাকের অন্তর্ভুক্ত:</span>
                  <ul className="space-y-1 text-xs text-stone-700 dark:text-stone-300">
                    {details.map((detail, dIdx) => (
                      <li key={dIdx} className="flex items-center gap-1.5">
                        <Check size={12} className="text-brand-emerald dark:text-emerald-400 shrink-0" strokeWidth={2.25} />
                        <span className="truncate">{detail}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Pricing and Action (8pt grid: pt-2, h-8 button) */}
                <div className="flex items-center justify-between mt-auto pt-2 border-t border-stone-100 dark:border-neutral-800">
                  <div className="tabular-nums">
                    <div className="text-xs text-stone-400 line-through leading-4">
                      ৳{product.oldPrice?.toLocaleString('en-IN')}
                    </div>
                    <div className="text-base sm:text-lg font-semibold text-brand-emerald dark:text-emerald-400 leading-6">
                      ৳{product.price.toLocaleString('en-IN')}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => handleCartAction(e, product)}
                    className={`h-8 px-3 rounded-md text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                      isAdded
                        ? 'bg-brand-emerald text-white'
                        : 'bg-stone-900 dark:bg-brand-emerald text-white hover:bg-brand-emerald dark:hover:bg-emerald-700'
                    }`}
                  >
                    {isAdded ? (
                      <>
                        <Check size={13} strokeWidth={2.5} />
                        <span>যুক্ত হয়েছে</span>
                      </>
                    ) : (
                      <>
                        <ShoppingCart size={13} />
                        <span>কার্টে যোগ করুন</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}
