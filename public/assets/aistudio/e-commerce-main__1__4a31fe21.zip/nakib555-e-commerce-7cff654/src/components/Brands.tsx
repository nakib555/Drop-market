import React from 'react';
import { TYPOGRAPHY_TOKENS } from '../theme';

interface Brand {
  id: string;
  name: string;
  logo: string;
}

export function Brands() {
  const brands: Brand[] = [
    { id: '1', name: 'দেশি বুটিক', logo: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=120&h=120' },
    { id: '2', name: 'আড়ং সিল্ক', logo: 'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&q=80&w=120&h=120' },
    { id: '3', name: 'খাদি ক্রাফট', logo: 'https://images.unsplash.com/photo-1479064555552-3ef4979f8908?auto=format&fit=crop&q=80&w=120&h=120' },
    { id: '4', name: 'অর্গানিক লাইফ', logo: 'https://images.unsplash.com/photo-1464965911861-746a04b4bca6?auto=format&fit=crop&q=80&w=120&h=120' },
    { id: '5', name: 'হ্যান্ডমেড বিডি', logo: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&q=80&w=120&h=120' },
    { id: '6', name: 'পিউর ফুড', logo: 'https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&q=80&w=120&h=120' },
  ];

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
      <div className="mb-3 sm:mb-4">
        <p className="text-xs font-medium text-brand-emerald dark:text-emerald-400 mb-0.5">সহযোগী প্রতিষ্ঠান</p>
        <h2 className={TYPOGRAPHY_TOKENS.sectionTitle}>জনপ্রিয় দেশীয় ব্র্যান্ডসমূহ</h2>
      </div>

      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 sm:gap-3">
        {brands.map((brand) => (
          <div 
            key={brand.id}
            className="group bg-white dark:bg-[#121316] border border-stone-200/80 dark:border-neutral-800 p-3 rounded-lg hover:border-brand-emerald/40 transition-colors duration-150 flex flex-col items-center justify-center text-center gap-2 cursor-pointer"
          >
            <div className="w-10 h-10 rounded-md overflow-hidden bg-stone-100 dark:bg-neutral-900 flex items-center justify-center border border-stone-200/60 dark:border-neutral-800">
              <img 
                src={brand.logo} 
                alt={brand.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
            </div>
            <span className="text-xs font-medium text-stone-800 dark:text-stone-200 group-hover:text-brand-emerald dark:group-hover:text-emerald-400 transition-colors">
              {brand.name}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}
