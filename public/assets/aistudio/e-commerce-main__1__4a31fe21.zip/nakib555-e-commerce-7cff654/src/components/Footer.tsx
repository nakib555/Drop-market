import React, { useState } from 'react';
import { Facebook, Instagram, Linkedin, ShoppingBag, Youtube, ChevronDown } from 'lucide-react';

function FooterAccordion({ title, children }: { title: string; children: React.ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="border-b border-white/10 py-3 md:border-none md:py-0">
      <button 
        type="button"
        onClick={() => setIsOpen(!isOpen)} 
        className="flex items-center justify-between w-full md:hidden font-sans font-semibold text-sm text-stone-100"
      >
        <span>{title}</span>
        <ChevronDown size={14} className={`transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      <h3 className="font-sans font-semibold text-sm tracking-wide text-white mb-3 hidden md:block">
        {title}
      </h3>
      <div className={`${isOpen ? 'block' : 'hidden'} md:block mt-2 md:mt-0`}>
        {children}
      </div>
    </div>
  );
}

export function Footer() {
  return (
    <footer className="bg-[#0B2E1F] text-stone-200 pt-8 md:pt-10 pb-16 md:pb-8 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-0 md:gap-6 lg:gap-6 mb-6 md:mb-8">
          
          {/* Brand Info */}
          <div className="lg:col-span-2 mb-6 md:mb-0">
            <a href="#home" onClick={(e) => e.preventDefault()} className="flex items-center gap-2 text-lg md:text-xl font-heading font-semibold text-white mb-3">
              <span className="w-7 h-7 rounded-lg bg-brand-emerald text-white flex items-center justify-center">
                <ShoppingBag size={15} />
              </span>
              <span>Deshi<span className="text-emerald-400">Mart</span></span>
            </a>
            <p className="text-stone-300 text-xs sm:text-sm leading-5 mb-4 max-w-sm">
              দেশি মার্ট বাংলাদেশের অন্যতম বিশ্বস্ত অনলাইন শপিং প্ল্যাটফর্ম। ঐতিহ্যবাহী পোশাক, হস্তশিল্প এবং বিশুদ্ধ অর্গানিক পণ্যের নির্ভরযোগ্য ঠিকানা।
            </p>
            <div className="flex items-center gap-2">
              {[
                { icon: Facebook, label: 'Facebook' },
                { icon: Youtube, label: 'YouTube' },
                { icon: Instagram, label: 'Instagram' },
                { icon: Linkedin, label: 'LinkedIn' },
              ].map(({ icon: Icon, label }) => (
                <a
                  key={label}
                  href={`#${label.toLowerCase()}`}
                  onClick={(e) => e.preventDefault()}
                  aria-label={label}
                  className="w-8 h-8 rounded-md bg-white/8 hover:bg-brand-emerald text-stone-200 hover:text-white flex items-center justify-center transition-colors border border-white/10"
                >
                  <Icon size={14} />
                </a>
              ))}
            </div>
          </div>

          <div className="flex flex-col md:contents">
            <FooterAccordion title="গ্রাহক সেবা">
              <ul className="space-y-2 text-xs sm:text-sm text-stone-300 pb-2 md:pb-0">
                <li><a href="#contact" onClick={(e) => e.preventDefault()} className="hover:text-white transition-colors">যোগাযোগ করুন</a></li>
                <li><a href="#delivery" onClick={(e) => e.preventDefault()} className="hover:text-white transition-colors">ডেলিভারি তথ্য</a></li>
                <li><a href="#returns" onClick={(e) => e.preventDefault()} className="hover:text-white transition-colors">রিটার্ন ও রিফান্ড নীতি</a></li>
                <li><a href="#size-guide" onClick={(e) => e.preventDefault()} className="hover:text-white transition-colors">সাইজ গাইড</a></li>
                <li><a href="#faq" onClick={(e) => e.preventDefault()} className="hover:text-white transition-colors">সাধারণ প্রশ্নাবলী</a></li>
              </ul>
            </FooterAccordion>

            <FooterAccordion title="আমার অ্যাকাউন্ট">
              <ul className="space-y-2 text-xs sm:text-sm text-stone-300 pb-2 md:pb-0">
                <li><a href="#profile" onClick={(e) => e.preventDefault()} className="hover:text-white transition-colors">প্রোফাইল বিবরণ</a></li>
                <li><a href="#orders" onClick={(e) => e.preventDefault()} className="hover:text-white transition-colors">আমার অর্ডারসমূহ</a></li>
                <li><a href="#wishlist" onClick={(e) => e.preventDefault()} className="hover:text-white transition-colors">পছন্দের তালিকা</a></li>
                <li><a href="#track" onClick={(e) => e.preventDefault()} className="hover:text-white transition-colors">অর্ডার ট্র্যাক করুন</a></li>
              </ul>
            </FooterAccordion>

            <FooterAccordion title="নীতিমালা ও তথ্য">
              <ul className="space-y-2 text-xs sm:text-sm text-stone-300 pb-2 md:pb-0">
                <li><a href="#about" onClick={(e) => e.preventDefault()} className="hover:text-white transition-colors">আমাদের সম্পর্কে</a></li>
                <li><a href="#privacy" onClick={(e) => e.preventDefault()} className="hover:text-white transition-colors">গোপনীয়তা নীতি</a></li>
                <li><a href="#terms" onClick={(e) => e.preventDefault()} className="hover:text-white transition-colors">ব্যবহারের শর্তাবলী</a></li>
                <li><a href="# authenticity" onClick={(e) => e.preventDefault()} className="hover:text-white transition-colors">মান নিয়ন্ত্রণ সনদ</a></li>
              </ul>
            </FooterAccordion>
          </div>
        </div>

        <div className="border-t border-white/10 pt-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-stone-400">
          <p>© ২০২৬ DeshiMart। সর্বস্বত্ব সংরক্ষিত।</p>
          <div className="flex flex-wrap justify-center items-center gap-3">
            <a href="#privacy" onClick={(e) => e.preventDefault()} className="hover:text-white transition-colors">গোপনীয়তা নীতি</a>
            <span aria-hidden="true">·</span>
            <a href="#terms" onClick={(e) => e.preventDefault()} className="hover:text-white transition-colors">শর্তাবলী</a>
            <span aria-hidden="true">·</span>
            <a href="#sitemap" onClick={(e) => e.preventDefault()} className="hover:text-white transition-colors">সাইটম্যাপ</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
