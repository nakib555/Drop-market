import React from 'react';
import { ArrowRight } from 'lucide-react';
import { ProductCard } from './ProductCard';
import { flashSaleProducts } from '../data';
import { Product } from '../types';
import { TYPOGRAPHY_TOKENS } from '../theme';

interface NewArrivalsProps {
  onProductClick?: (product: Product) => void;
  onAddToCart?: (product: Product, quantity: number) => void;
}

export function NewArrivals({ onProductClick, onAddToCart }: NewArrivalsProps) {
  const newProducts = flashSaleProducts.filter(p => p.isNew);

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
      <div className="flex items-end justify-between mb-3 sm:mb-4">
        <div>
          <p className="text-xs font-medium text-brand-emerald dark:text-emerald-400 mb-0.5">নতুন সংযোজন</p>
          <h2 className={TYPOGRAPHY_TOKENS.sectionTitle}>নতুন কালেকশন</h2>
        </div>
        <a 
          href="#new-arrivals"
          onClick={(e) => e.preventDefault()}
          className="text-xs font-semibold text-stone-700 dark:text-stone-300 hover:text-brand-emerald dark:hover:text-emerald-400 flex items-center gap-1 transition-colors whitespace-nowrap"
        >
          <span>সব দেখুন</span>
          <ArrowRight size={13} />
        </a>
      </div>

      <div className="flex md:grid overflow-x-auto md:overflow-visible hide-scrollbar snap-x snap-mandatory md:snap-none md:grid-cols-3 gap-3 pb-2 md:pb-0 -mx-4 px-4 md:mx-0 md:px-0">
        {newProducts.map(product => (
          <div key={product.id} className="min-w-[44vw] sm:min-w-[200px] md:min-w-0 snap-start shrink-0 w-[44vw] md:w-auto flex flex-col">
            <ProductCard 
              product={product} 
              onProductClick={onProductClick}
              onAddToCart={onAddToCart}
            />
          </div>
        ))}
      </div>
    </section>
  );
}
