import React from 'react';
import { Product } from '../types';
import { Heart, ShoppingCart, Star } from 'lucide-react';
import { TYPOGRAPHY_TOKENS } from '../theme';

interface ProductCardProps {
  product: Product;
  featured?: boolean;
  onProductClick?: (product: Product) => void;
  onAddToCart?: (product: Product, quantity: number) => void;
  key?: React.Key;
}

export function ProductCard({ product, onProductClick, onAddToCart }: ProductCardProps) {
  return (
    <article 
      onClick={() => onProductClick?.(product)}
      className="bg-white dark:bg-[#121316] rounded-lg sm:rounded-xl overflow-hidden border border-stone-200/80 dark:border-neutral-800 hover:border-stone-300 dark:hover:border-neutral-700 transition-colors duration-150 group relative flex flex-col h-full cursor-pointer"
    >
      {/* Single restrained status tag (8pt grid: top-2 left-2) */}
      {(product.discount || product.isNew) && (
        <div className="absolute top-2 left-2 z-10">
          {product.discount ? (
            <span className="bg-stone-900/90 dark:bg-white/90 text-white dark:text-stone-900 text-2xs font-semibold tabular-nums px-2 py-0.5 rounded backdrop-blur-xs">
              -{product.discount}%
            </span>
          ) : product.isNew ? (
            <span className="bg-brand-emerald text-white text-2xs font-semibold px-2 py-0.5 rounded">
              নতুন
            </span>
          ) : null}
        </div>
      )}

      {/* Wishlist Button (8pt grid: top-2 right-2, w-7 h-7) */}
      <button 
        type="button"
        aria-label="উইশলিস্টে যোগ করুন"
        onClick={(e) => {
          e.stopPropagation();
        }}
        className="absolute top-2 right-2 z-10 w-7 h-7 bg-white/90 dark:bg-neutral-900/85 backdrop-blur-xs rounded-md flex items-center justify-center text-stone-500 hover:text-rose-600 hover:bg-white dark:hover:bg-neutral-800 transition-colors duration-150 border border-stone-200/60 dark:border-neutral-700 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 cursor-pointer"
      >
        <Heart size={13} />
      </button>

      {/* Product Imagery (1:1 aspect-square) */}
      <div className="relative aspect-square overflow-hidden bg-[#F5F4F0] dark:bg-[#18191C]">
        <img 
          src={product.image} 
          alt={product.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
        />
        
        {/* Quick Add Overlay on Desktop Hover (8pt grid: p-2, h-8 button) */}
        <div className="absolute inset-x-0 bottom-0 p-2 opacity-0 group-hover:opacity-100 transition-all translate-y-1 group-hover:translate-y-0 duration-150 hidden md:block">
          <button 
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              if (onAddToCart) onAddToCart(product, 1);
            }}
            className="w-full h-8 bg-stone-900/95 dark:bg-white/95 backdrop-blur-xs text-white dark:text-stone-900 text-xs font-medium px-3 rounded-md hover:bg-brand-emerald dark:hover:bg-brand-emerald dark:hover:text-white transition-colors flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <ShoppingCart size={13} />
            <span>কার্টে যোগ করুন</span>
          </button>
        </div>
      </div>

      {/* Card Body & Typography (8pt grid: p-3 = 12px, gap-2 = 8px) */}
      <div className="p-3 flex flex-col flex-1 justify-between gap-2">
        <div>
          {/* Unboxed metadata row */}
          <div className="flex items-center gap-1 text-xs text-stone-500 dark:text-stone-400 mb-1 tabular-nums">
            <Star size={11} className="fill-amber-500 text-amber-500 shrink-0" />
            <span className="font-medium text-stone-700 dark:text-stone-300">{product.rating}</span>
            <span aria-hidden="true">·</span>
            <span>{product.reviews} রিভিউ</span>
          </div>

          <h3 className={`${TYPOGRAPHY_TOKENS.cardTitle} group-hover:text-brand-emerald dark:group-hover:text-emerald-400 transition-colors`}>
            {product.name}
          </h3>
        </div>
        
        <div className="pt-2 flex items-center justify-between gap-2 border-t border-stone-100 dark:border-neutral-800/80">
          <div className="flex items-baseline gap-1.5 flex-wrap tabular-nums">
            <span className={TYPOGRAPHY_TOKENS.price}>
              ৳{product.price.toLocaleString('en-IN')}
            </span>
            {product.oldPrice && (
              <span className="text-xs text-stone-400 dark:text-stone-500 line-through">
                ৳{product.oldPrice.toLocaleString('en-IN')}
              </span>
            )}
          </div>
          
          <button 
            type="button"
            aria-label={`${product.name} কার্টে যোগ করুন`}
            onClick={(e) => {
              e.stopPropagation();
              if (onAddToCart) onAddToCart(product, 1);
            }}
            className="w-8 h-8 rounded-md bg-stone-100 dark:bg-neutral-800 border border-stone-200/70 dark:border-neutral-700 flex items-center justify-center text-stone-700 dark:text-stone-200 hover:bg-brand-emerald hover:text-white hover:border-brand-emerald transition-colors shrink-0 cursor-pointer"
          >
            <ShoppingCart size={13} />
          </button>
        </div>
      </div>
    </article>
  );
}
