import React from 'react';
import { Home, Grid, ClipboardList, User, MoreHorizontal } from 'lucide-react';
import { motion } from 'motion/react';

interface MobileNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function MobileNav({ activeTab, onTabChange }: MobileNavProps) {
  const navItems = [
    { id: 'home', label: 'হোম', icon: Home },
    { id: 'categories', label: 'ক্যাটাগরি', icon: Grid },
    { id: 'orders', label: 'অর্ডার', icon: ClipboardList },
    { id: 'profile', label: 'প্রোফাইল', icon: User },
    { id: 'more', label: 'আরও', icon: MoreHorizontal },
  ];

  return (
    <nav
      aria-label="মোবাইল বটম নেভিগেশন"
      className="md:hidden fixed bottom-0 left-0 right-0 bg-white/95 dark:bg-[#121315]/95 backdrop-blur-md border-t border-stone-200/80 dark:border-neutral-800 z-50 h-14 px-2 pb-[env(safe-area-inset-bottom)] flex justify-around items-center w-full"
    >
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = activeTab === item.id;
        return (
          <button
            key={item.id}
            type="button"
            onClick={() => onTabChange(item.id)}
            className={`relative flex flex-col items-center justify-center h-10 px-2 rounded-lg transition-colors duration-200 cursor-pointer ${
              isActive 
                ? 'text-brand-emerald dark:text-emerald-400 font-semibold' 
                : 'text-stone-500 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
            }`}
          >
            {isActive && (
              <motion.span
                layoutId="mobileActiveTopLine"
                className="absolute top-[-7px] left-1/2 -translate-x-1/2 w-4 h-0.5 bg-brand-emerald dark:bg-emerald-400 rounded-full"
                transition={{ type: 'spring', stiffness: 380, damping: 28 }}
              />
            )}

            <Icon size={18} strokeWidth={isActive ? 2 : 1.75} />
            <span className="text-xs mt-1 leading-none">
              {item.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
