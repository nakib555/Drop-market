import React from 'react';
import { ArrowRight } from 'lucide-react';
import { ProductCard } from './ProductCard';
import { flashSaleProducts } from '../data';
import { Product } from '../types';
import { TYPOGRAPHY_TOKENS } from '../theme';

interface FlashSaleProps {
  onProductClick?: (product: Product) => void;
  onAddToCart?: (product: Product, quantity: number) => void;
}

export function FlashSale({ onProductClick, onAddToCart }: FlashSaleProps) {
  return (
    <section id="flash-sale" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
      {/* Mobile Header */}
      <div className="md:hidden flex flex-col gap-2 mb-3">
        <div className="flex items-end justify-between">
          <div>
            <p className="text-xs font-medium text-brand-orange mb-0.5">সীমিত সময়ের অফার</p>
            <h2 className={TYPOGRAPHY_TOKENS.sectionTitle}>ফ্ল্যাশ সেল</h2>
          </div>
          <a
            href="#all-flash-deals"
            onClick={(e) => e.preventDefault()}
            className="text-brand-emerald font-semibold flex items-center gap-1 text-xs"
          >
            সব দেখুন <ArrowRight size={13} />
          </a>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-stone-600 dark:text-stone-300 tabular-nums">
          <span>সময় বাকি:</span>
          <span className="font-mono font-semibold bg-stone-900 text-white dark:bg-stone-100 dark:text-stone-900 px-2 py-0.5 rounded">০২ ঘণ্টা</span>
          <span>:</span>
          <span className="font-mono font-semibold bg-stone-900 text-white dark:bg-stone-100 dark:text-stone-900 px-2 py-0.5 rounded">১৮ মিনিট</span>
          <span>:</span>
          <span className="font-mono font-semibold bg-stone-900 text-white dark:bg-stone-100 dark:text-stone-900 px-2 py-0.5 rounded">৪৫ সেকেন্ড</span>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-3 sm:gap-4">
        {/* Desktop Editorial Flash Sale Panel (8pt grid: p-4 xl:p-6, rounded-xl) */}
        <div className="hidden lg:flex lg:w-1/4 bg-brand-dark text-white rounded-xl p-4 xl:p-6 flex-col justify-between relative overflow-hidden border border-brand-emerald/30">
          <div>
            <p className="text-xs font-medium text-emerald-300 tracking-wide mb-1">সীমিত সময়ের বিশেষ ছাড়</p>
            <h2 className="font-heading text-lg xl:text-xl font-semibold text-white tracking-tight leading-6 mb-2">
              ফ্ল্যাশ সেল কালেকশন
            </h2>
            <p className="text-stone-300 text-xs sm:text-sm leading-5 mb-4">
              নির্বাচিত পণ্যে সর্বোচ্চ ২৯% পর্যন্ত বিশেষ মূল্যছাড়। স্টক শেষ হওয়ার আগেই অর্ডার করুন।
            </p>
            
            {/* Tabular Countdown Blocks (8pt grid: gap-2, p-2, rounded-lg) */}
            <div className="grid grid-cols-3 gap-2 mb-4 tabular-nums">
              <div className="bg-white/10 border border-white/15 rounded-lg p-2 text-center">
                <div className="font-mono text-base xl:text-lg font-semibold text-white">০২</div>
                <div className="text-2xs text-stone-300 mt-0.5">ঘণ্টা</div>
              </div>
              <div className="bg-white/10 border border-white/15 rounded-lg p-2 text-center">
                <div className="font-mono text-base xl:text-lg font-semibold text-white">১৮</div>
                <div className="text-2xs text-stone-300 mt-0.5">মিনিট</div>
              </div>
              <div className="bg-white/10 border border-white/15 rounded-lg p-2 text-center">
                <div className="font-mono text-base xl:text-lg font-semibold text-white">৪৫</div>
                <div className="text-2xs text-stone-300 mt-0.5">সেকেন্ড</div>
              </div>
            </div>
          </div>

          <a
            href="#all-flash-deals"
            onClick={(e) => e.preventDefault()}
            className="h-9 bg-white text-stone-900 hover:bg-stone-100 px-4 rounded-lg text-xs sm:text-sm font-medium transition-colors inline-flex items-center justify-center gap-1.5 w-full whitespace-nowrap"
          >
            <span>সবগুলো ডিল দেখুন</span>
            <ArrowRight size={14} />
          </a>
        </div>

        {/* Products Grid Area (8pt grid: gap-3) */}
        <div className="lg:w-3/4 flex flex-col">
          <div className="flex md:grid overflow-x-auto md:overflow-visible hide-scrollbar snap-x snap-mandatory md:snap-none md:grid-cols-3 gap-3 pb-2 md:pb-0 -mx-4 px-4 md:mx-0 md:px-0">
            {flashSaleProducts.slice(0, 3).map(product => (
              <div key={product.id} className="min-w-[44vw] sm:min-w-[200px] md:min-w-0 snap-start shrink-0 w-[44vw] md:w-auto flex flex-col">
                <ProductCard 
                  product={product} 
                  onProductClick={onProductClick}
                  onAddToCart={onAddToCart}
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
