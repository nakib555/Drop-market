import React from 'react';
import { ArrowRight } from 'lucide-react';

export function PromoBanners() {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
        {/* Banner 1 (8pt grid: h-40 = 160px, sm:h-44 = 176px, p-4 sm:p-6) */}
        <div className="relative rounded-xl overflow-hidden h-40 sm:h-44 group bg-[#EFF5F1] dark:bg-[#131F1A] border border-stone-200/80 dark:border-neutral-800 flex items-center">
          <div className="p-4 sm:p-6 flex flex-col justify-center max-w-[62%] z-10">
            <span className="text-brand-emerald dark:text-emerald-400 text-xs font-medium mb-1">নতুন গ্রাহকদের জন্য</span>
            <h3 className="text-lg sm:text-xl font-heading font-semibold text-stone-900 dark:text-white mb-1 leading-6">
              প্রথম অর্ডারে ১০% ছাড়
            </h3>
            <p className="text-stone-600 dark:text-stone-300 text-xs sm:text-sm mb-3 leading-5">
              চেকআউটে <strong className="font-mono font-semibold text-stone-900 dark:text-white">EID2026</strong> কোড ব্যবহার করুন
            </p>
            <a
              href="#featured-collection"
              className="h-8 bg-brand-emerald hover:bg-brand-dark text-white px-3 rounded-lg text-xs font-medium transition-colors w-max inline-flex items-center gap-1.5 whitespace-nowrap"
            >
              <span>এখনই শপ করুন</span>
              <ArrowRight size={13} />
            </a>
          </div>
          <div className="absolute right-0 top-0 bottom-0 w-[38%] flex items-center justify-end pr-4 sm:pr-6">
            <img 
              src="https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&q=80&w=400&h=400" 
              alt="উপহার বক্স"
              referrerPolicy="no-referrer"
              className="w-24 h-24 sm:w-32 sm:h-32 object-cover rounded-lg group-hover:scale-103 transition-transform duration-500"
            />
          </div>
        </div>

        {/* Banner 2 */}
        <div className="relative rounded-xl overflow-hidden h-40 sm:h-44 group bg-[#F8F3E8] dark:bg-[#1F1A12] border border-stone-200/80 dark:border-neutral-800 flex items-center">
          <div className="p-4 sm:p-6 flex flex-col justify-center max-w-[62%] z-10">
            <span className="text-amber-800 dark:text-amber-400 text-xs font-medium mb-1">উৎসবের আয়োজন</span>
            <h3 className="text-lg sm:text-xl font-heading font-semibold text-stone-900 dark:text-white mb-1 leading-6">
              এক্সক্লুসিভ হেরিটেজ সম্ভার
            </h3>
            <p className="text-stone-600 dark:text-stone-300 text-xs sm:text-sm mb-3 leading-5">
              নির্বাচিত তাঁত ও হস্তশিল্প পণ্যে বিশেষ মূল্যছাড়
            </p>
            <a
              href="#flash-sale"
              className="h-8 bg-stone-900 dark:bg-amber-600 hover:bg-stone-800 dark:hover:bg-amber-700 text-white px-3 rounded-lg text-xs font-medium transition-colors w-max inline-flex items-center gap-1.5 whitespace-nowrap"
            >
              <span>কালেকশন দেখুন</span>
              <ArrowRight size={13} />
            </a>
          </div>
          <div className="absolute right-0 top-0 bottom-0 w-[38%] flex items-center justify-end pr-4 sm:pr-6">
            <img 
              src="https://images.unsplash.com/photo-1540959733332-eab4deceeaf7?auto=format&fit=crop&q=80&w=400&h=400" 
              alt="হেরিটেজ লণ্ঠন"
              referrerPolicy="no-referrer"
              className="w-24 h-24 sm:w-32 sm:h-32 object-cover rounded-lg group-hover:scale-103 transition-transform duration-500"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
