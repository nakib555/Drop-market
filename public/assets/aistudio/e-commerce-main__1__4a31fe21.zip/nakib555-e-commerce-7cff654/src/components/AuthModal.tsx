import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Mail, Lock, Phone, ShieldCheck, Eye, EyeOff, Sparkles, ArrowRight, CheckCircle2, ShoppingBag } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: { name: string; email: string; phone: string; address: string }) => void;
  redirectReason?: string; // e.g. "পণ্য কিনতে অনুগ্রহ করে লগইন করুন"
}

export function AuthModal({ isOpen, onClose, onLoginSuccess, redirectReason }: AuthModalProps) {
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [loginType, setLoginType] = useState<'phone' | 'email'>('phone');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Form Fields
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [otpCountdown, setOtpCountdown] = useState(60);
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');

  // Errors
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isOtpSent && otpCountdown > 0) {
      timer = setTimeout(() => setOtpCountdown(otpCountdown - 1), 1000);
    }
    return () => clearTimeout(timer);
  }, [isOtpSent, otpCountdown]);

  if (!isOpen) return null;

  const handleSendOtp = (e: React.MouseEvent) => {
    e.preventDefault();
    if (!phone || phone.length < 11) {
      setErrors({ phone: 'অনুগ্রহ করে সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন' });
      return;
    }
    setErrors({});
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setIsOtpSent(true);
      setOtpCountdown(60);
    }, 1200);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!otp || otp.length < 4) {
      setErrors({ otp: 'অনুগ্রহ করে সঠিক ৪ ডিজিটের ওটিপি (OTP) দিন' });
      return;
    }
    setErrors({});
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      onLoginSuccess({
        name: name || 'রকিব হাসান',
        email: email || 'rakib@example.com',
        phone: phone.startsWith('+880') ? phone : `+880 ${phone.replace(/^0/, '')}`,
        address: address || 'বাসা ১২, রোড ৪, ধানমন্ডি, ঢাকা',
      });
      onClose();
    }, 1500);
  };

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: Record<string, string> = {};
    if (!email || !email.includes('@')) {
      newErrors.email = 'সঠিক ইমেল ঠিকানা লিখুন';
    }
    if (!password || password.length < 6) {
      newErrors.password = 'পাসওয়ার্ড অন্তত ৬ অক্ষরের হতে হবে';
    }
    if (authMode === 'signup' && !name.trim()) {
      newErrors.name = 'আপনার নাম লিখুন';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      onLoginSuccess({
        name: name || 'রকিব হাসান',
        email: email,
        phone: phone || '+880 1712 345678',
        address: address || 'বাসা ১২, রোড ৪, ধানমন্ডি, ঢাকা',
      });
      onClose();
    }, 1500);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.6 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/60 backdrop-blur-sm"
        />

        {/* Modal Container */}
        <motion.div
          initial={{ scale: 0.96, opacity: 0, y: 12 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.96, opacity: 0, y: 12 }}
          transition={{ type: 'spring', damping: 25, stiffness: 250 }}
          className="relative bg-white dark:bg-[#121316] rounded-xl sm:rounded-2xl w-full max-w-md overflow-hidden shadow-2xl border border-stone-200/80 dark:border-neutral-800"
        >
          {/* Top colored accent bar */}
          <div className="h-1 bg-gradient-to-r from-brand-emerald via-[#6DB33F] to-brand-gold w-full" />

          {/* Close button (w-8 h-8 = 32px) */}
          <button
            onClick={onClose}
            className="absolute top-3 right-3 w-8 h-8 rounded-lg hover:bg-stone-100 dark:hover:bg-neutral-800 text-stone-400 hover:text-stone-600 dark:hover:text-stone-300 flex items-center justify-center transition-colors z-10"
          >
            <X size={16} />
          </button>

          <div className="p-5 sm:p-6">
            {/* Header / Brand Logo */}
            <div className="text-center mb-4">
              <div className="inline-flex items-center gap-2 text-xl font-heading font-semibold text-stone-900 dark:text-white mb-1">
                <span className="w-7 h-7 rounded-lg bg-brand-emerald text-white flex items-center justify-center">
                  <ShoppingBag size={15} />
                </span>
                <span>Deshi<span className="text-brand-emerald dark:text-emerald-400">Mart</span></span>
              </div>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                বাংলাদেশের ঐতিহ্যবাহী ও অর্গানিক পণ্যের বিশ্বস্ত অনলাইন স্টোর
              </p>

              {/* Redirect warning / Buying constraints info */}
              {redirectReason && (
                <div className="mt-3 p-2.5 bg-amber-50 dark:bg-amber-950/20 text-amber-800 dark:text-amber-300 rounded-lg border border-amber-200/60 dark:border-amber-900/30 text-xs font-medium flex items-center justify-center gap-2">
                  <Sparkles size={13} className="shrink-0" />
                  <span>{redirectReason}</span>
                </div>
              )}
            </div>

            {/* Auth mode switcher (Login / Signup) */}
            <div className="flex bg-stone-100 dark:bg-neutral-900 p-1 rounded-lg mb-4">
              <button
                onClick={() => {
                  setAuthMode('login');
                  setErrors({});
                }}
                className={`flex-1 h-8 text-xs font-semibold rounded-md transition-all ${
                  authMode === 'login'
                    ? 'bg-white dark:bg-[#121316] text-stone-900 dark:text-brand-emerald shadow-xs'
                    : 'text-stone-500 hover:text-stone-700 dark:hover:text-stone-300'
                }`}
              >
                লগইন
              </button>
              <button
                onClick={() => {
                  setAuthMode('signup');
                  setErrors({});
                }}
                className={`flex-1 h-8 text-xs font-semibold rounded-md transition-all ${
                  authMode === 'signup'
                    ? 'bg-white dark:bg-[#121316] text-stone-900 dark:text-brand-emerald shadow-xs'
                    : 'text-stone-500 hover:text-stone-700 dark:hover:text-stone-300'
                }`}
              >
                নতুন অ্যাকাউন্ট
              </button>
            </div>

            {/* Sub-tab: Phone vs Email switcher (Only for Login) */}
            {authMode === 'login' && (
              <div className="flex gap-4 justify-center mb-4">
                <button
                  onClick={() => setLoginType('phone')}
                  className={`text-xs font-semibold pb-1 border-b-2 transition-all ${
                    loginType === 'phone'
                      ? 'border-brand-emerald text-brand-emerald'
                      : 'border-transparent text-stone-400 hover:text-stone-600 dark:hover:text-stone-300'
                  }`}
                >
                  মোবাইল নম্বর দিয়ে
                </button>
                <button
                  onClick={() => setLoginType('email')}
                  className={`text-xs font-semibold pb-1 border-b-2 transition-all ${
                    loginType === 'email'
                      ? 'border-brand-emerald text-brand-emerald'
                      : 'border-transparent text-stone-400 hover:text-stone-600 dark:hover:text-stone-300'
                  }`}
                >
                  ইমেইল দিয়ে
                </button>
              </div>
            )}

            {/* Dynamic Form Content */}
            {authMode === 'login' && loginType === 'phone' ? (
              /* PHONE LOGIN / OTP */
              <div className="space-y-3">
                {!isOtpSent ? (
                  <div>
                    <label className="block text-xs font-medium text-stone-600 dark:text-stone-400 mb-1">
                      মোবাইল নম্বর
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-stone-400 text-xs font-semibold border-r border-stone-200 dark:border-neutral-800 pr-2">
                        +৮৮
                      </div>
                      <input
                        type="tel"
                        placeholder="017XXXXXXXX"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value.replace(/[^0-9]/g, ''))}
                        className="block w-full h-9 pl-14 pr-3 border border-stone-200 dark:border-neutral-800 bg-stone-50 dark:bg-neutral-900 dark:text-white rounded-lg text-xs sm:text-sm focus:outline-none focus:border-brand-emerald font-medium"
                        maxLength={11}
                      />
                    </div>
                    {errors.phone && (
                      <p className="text-xs text-red-500 mt-1 font-medium">{errors.phone}</p>
                    )}

                    <button
                      onClick={handleSendOtp}
                      disabled={isLoading}
                      className="w-full h-9 mt-4 bg-brand-emerald hover:bg-brand-dark text-white rounded-lg text-xs sm:text-sm font-medium transition-colors flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-75"
                    >
                      {isLoading ? (
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <>
                          <span>ওটিপি পাঠান (Send OTP)</span>
                          <ArrowRight size={14} />
                        </>
                      )}
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleVerifyOtp} className="space-y-3">
                    <div className="bg-emerald-50/50 dark:bg-emerald-950/10 p-3 rounded-lg border border-brand-emerald/15 text-center">
                      <p className="text-xs text-brand-emerald font-medium">
                        আমরা +৮৮ {phone} নম্বরে একটি ওটিপি কোড পাঠিয়েছি
                      </p>
                      <button
                        type="button"
                        onClick={() => setIsOtpSent(false)}
                        className="text-xs text-stone-400 hover:text-brand-emerald underline mt-1 font-medium"
                      >
                        নম্বর পরিবর্তন করুন
                      </button>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-stone-600 dark:text-stone-400 mb-1">
                        ৪ ডিজিট ওটিপি কোড (OTP)
                      </label>
                      <input
                        type="text"
                        placeholder="XXXX"
                        value={otp}
                        onChange={(e) => setOtp(e.target.value.replace(/[^0-9]/g, ''))}
                        className="block w-full h-9 px-3 border border-stone-200 dark:border-neutral-800 bg-stone-50 dark:bg-neutral-900 dark:text-white rounded-lg text-sm focus:outline-none focus:border-brand-emerald text-center tracking-widest font-semibold"
                        maxLength={4}
                      />
                      {errors.otp && (
                        <p className="text-xs text-red-500 mt-1 font-medium">{errors.otp}</p>
                      )}
                    </div>

                    <div className="flex justify-between items-center text-xs">
                      <span className="text-stone-400">কোড পাননি?</span>
                      {otpCountdown > 0 ? (
                        <span className="text-stone-400 font-medium">পুনরায় পাঠান ({otpCountdown} সেকেন্ড)</span>
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            setOtpCountdown(60);
                          }}
                          className="text-brand-emerald font-semibold hover:underline"
                        >
                          কোড পুনরায় পাঠান
                        </button>
                      )}
                    </div>

                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full h-9 bg-brand-emerald hover:bg-brand-dark text-white rounded-lg text-xs sm:text-sm font-medium transition-colors flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-75"
                    >
                      {isLoading ? (
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <>
                          <ShieldCheck size={15} />
                          <span>ভেরিফাই করুন ও লগইন করুন</span>
                        </>
                      )}
                    </button>
                  </form>
                )}
              </div>
            ) : (
              /* EMAIL LOGIN or SIGNUP */
              <form onSubmit={handleEmailSubmit} className="space-y-3">
                {authMode === 'signup' && (
                  <div>
                    <label className="block text-xs font-medium text-stone-600 dark:text-stone-400 mb-1">
                      আপনার নাম
                    </label>
                    <input
                      type="text"
                      placeholder="মোঃ রকিব হাসান"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="block w-full h-9 px-3 border border-stone-200 dark:border-neutral-800 bg-stone-50 dark:bg-neutral-900 dark:text-white rounded-lg text-xs sm:text-sm focus:outline-none focus:border-brand-emerald font-medium"
                    />
                    {errors.name && (
                      <p className="text-xs text-red-500 mt-1 font-medium">{errors.name}</p>
                    )}
                  </div>
                )}

                <div>
                  <label className="block text-xs font-medium text-stone-600 dark:text-stone-400 mb-1">
                    ইমেইল এড্রেস
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-2.5 text-stone-400" size={15} />
                    <input
                      type="email"
                      placeholder="example@gmail.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="block w-full h-9 pl-9 pr-3 border border-stone-200 dark:border-neutral-800 bg-stone-50 dark:bg-neutral-900 dark:text-white rounded-lg text-xs sm:text-sm focus:outline-none focus:border-brand-emerald font-medium"
                    />
                  </div>
                  {errors.email && (
                    <p className="text-xs text-red-500 mt-1 font-medium">{errors.email}</p>
                  )}
                </div>

                {authMode === 'signup' && (
                  <div>
                    <label className="block text-xs font-medium text-stone-600 dark:text-stone-400 mb-1">
                      মোবাইল নম্বর
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-2.5 text-stone-400" size={15} />
                      <input
                        type="tel"
                        placeholder="017XXXXXXXX"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value.replace(/[^0-9]/g, ''))}
                        className="block w-full h-9 pl-9 pr-3 border border-stone-200 dark:border-neutral-800 bg-stone-50 dark:bg-neutral-900 dark:text-white rounded-lg text-xs sm:text-sm focus:outline-none focus:border-brand-emerald font-medium"
                        maxLength={11}
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-medium text-stone-600 dark:text-stone-400 mb-1">
                    পাসওয়ার্ড
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 text-stone-400" size={15} />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="block w-full h-9 pl-9 pr-9 border border-stone-200 dark:border-neutral-800 bg-stone-50 dark:bg-neutral-900 dark:text-white rounded-lg text-xs sm:text-sm focus:outline-none focus:border-brand-emerald font-medium"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-stone-400 hover:text-stone-600 dark:hover:text-stone-300"
                    >
                      {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>
                  {errors.password && (
                    <p className="text-xs text-red-500 mt-1 font-medium">{errors.password}</p>
                  )}
                </div>

                {authMode === 'signup' && (
                  <div>
                    <label className="block text-xs font-medium text-stone-600 dark:text-stone-400 mb-1">
                      ডেলিভারি ঠিকানা (ঐচ্ছিক)
                    </label>
                    <textarea
                      placeholder="বাসা, সড়ক, এলাকা, জেলা"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      className="block w-full px-3 py-2 border border-stone-200 dark:border-neutral-800 bg-stone-50 dark:bg-neutral-900 dark:text-white rounded-lg text-xs sm:text-sm focus:outline-none focus:border-brand-emerald font-medium h-14 resize-none"
                    />
                  </div>
                )}

                {authMode === 'login' && (
                  <div className="text-right">
                    <a href="#" className="text-xs text-brand-emerald hover:underline font-medium">
                      পাসওয়ার্ড ভুলে গেছেন?
                    </a>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full h-9 bg-brand-emerald hover:bg-brand-dark text-white rounded-lg text-xs sm:text-sm font-medium transition-colors flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-75"
                >
                  {isLoading ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>{authMode === 'login' ? 'লগইন করুন' : 'অ্যাকাউন্ট তৈরি করুন'}</span>
                      <ArrowRight size={14} />
                    </>
                  )}
                </button>
              </form>
            )}

            {/* Quick social login / Help banner */}
            <div className="mt-5 pt-4 border-t border-stone-100 dark:border-neutral-800 text-center">
              <span className="text-xs text-stone-400 font-medium block mb-2">
                অথবা সামাজিক যোগাযোগ মাধ্যমে
              </span>
              <div className="flex justify-center gap-2">
                <button
                  onClick={() => {
                    setIsLoading(true);
                    setTimeout(() => {
                      setIsLoading(false);
                      onLoginSuccess({
                        name: 'নাকিব হাসান',
                        email: 'nakib@example.com',
                        phone: '+880 1812 987654',
                        address: 'ধানমন্ডি, ঢাকা',
                      });
                      onClose();
                    }, 1000);
                  }}
                  className="h-8 px-3 bg-[#1877F2]/10 dark:bg-[#1877F2]/20 text-[#1877F2] rounded-lg text-xs font-semibold hover:bg-[#1877F2]/20 transition-colors flex items-center gap-1.5"
                >
                  Facebook
                </button>
                <button
                  onClick={() => {
                    setIsLoading(true);
                    setTimeout(() => {
                      setIsLoading(false);
                      onLoginSuccess({
                        name: 'নাকিব হাসান',
                        email: 'nakib@example.com',
                        phone: '+880 1812 987654',
                        address: 'ধানমন্ডি, ঢাকা',
                      });
                      onClose();
                    }, 1000);
                  }}
                  className="h-8 px-3 bg-stone-100 dark:bg-neutral-900 text-stone-700 dark:text-stone-300 rounded-lg text-xs font-semibold hover:bg-stone-200 dark:hover:bg-neutral-800 transition-colors flex items-center gap-1.5 border border-stone-200 dark:border-neutral-800"
                >
                  Google
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
