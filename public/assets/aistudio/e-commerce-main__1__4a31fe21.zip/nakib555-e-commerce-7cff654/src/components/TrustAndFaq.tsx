import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, Truck, RotateCcw, BadgeCheck, ChevronDown } from 'lucide-react';
import { TYPOGRAPHY_TOKENS } from '../theme';

interface FaqItem {
  question: string;
  answer: string;
}

export function TrustAndFaq() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const trustItems = [
    {
      id: 1,
      icon: <BadgeCheck className="text-brand-emerald dark:text-emerald-400" size={22} />,
      title: '১০০% খাঁটি ও অর্গানিক',
      description: 'সরাসরি কৃষক ও বিশ্বস্ত খামার থেকে সংগৃহীত ভেজালমুক্ত পণ্যের নিশ্চয়তা।'
    },
    {
      id: 2,
      icon: <Truck className="text-brand-emerald dark:text-emerald-400" size={22} />,
      title: 'দ্রুত ও নিরাপদ ডেলিভারি',
      description: 'ঢাকায় ২৪–৪৮ ঘণ্টা এবং সারাদেশে ৩–৫ কার্যদিবসের মধ্যে হোম ডেলিভারি।'
    },
    {
      id: 3,
      icon: <RotateCcw className="text-brand-emerald dark:text-emerald-400" size={22} />,
      title: '৭ দিনের সহজ রিটার্ন',
      description: 'পণ্যে কোনো ত্রুটি থাকলে ৭ দিনের মধ্যে বিনামূল্যে এক্সচেঞ্জ বা রিফান্ড।'
    },
    {
      id: 4,
      icon: <ShieldCheck className="text-brand-emerald dark:text-emerald-400" size={22} />,
      title: 'নিরাপদ পেমেন্ট ও COD',
      description: 'বিকাশ, নগদ, কার্ড কিংবা পণ্য হাতে পেয়ে ক্যাশ অন ডেলিভারি সুবিধা।'
    }
  ];

  const faqs: FaqItem[] = [
    {
      question: 'আপনাদের পণ্যগুলো কি সত্যিই ১০০% খাঁটি?',
      answer: 'জী, আমাদের সুন্দরবনের মধু, গাওয়া ঘি এবং সরিষার তেলসহ সকল খাদ্যপণ্য নিজস্ব তত্ত্বাবধানে সরাসরি উৎস থেকে সংগ্রহ করা হয়। আমরা শতভাগ বিশুদ্ধতার নিশ্চয়তা দিচ্ছি।'
    },
    {
      question: 'ডেলিভারি চার্জ কত এবং কতদিনের মধ্যে পাবো?',
      answer: 'ঢাকা সিটির ভেতরে ডেলিভারি চার্জ ৫০ টাকা এবং ঢাকার বাইরে ১০০ টাকা (৳১,৪৯৯+ অর্ডারে ফ্রি)। ঢাকা সিটির ভেতরে ২৪–৪৮ ঘণ্টার মধ্যে এবং ঢাকার বাইরে ৩–৫ দিনের মধ্যে ডেলিভারি সম্পন্ন করা হয়।'
    },
    {
      question: 'আমি কি ক্যাশ অন ডেলিভারি (COD) সুবিধা পাবো?',
      answer: 'জী অবশ্যই। আপনি পুরো বাংলাদেশেই ক্যাশ অন ডেলিভারি সুবিধা পাবেন। পণ্য হাতে পেয়ে দেখে তারপর মূল্য পরিশোধ করতে পারবেন।'
    },
    {
      question: 'পণ্যে কোনো সমস্যা থাকলে ফেরত দেওয়ার নিয়ম কী?',
      answer: 'পণ্য গ্রহণের সময় কোনো ত্রুটি বা সমস্যা থাকলে সাথে সাথে আমাদের ডেলিভারি পার্টনারকে জানান অথবা ২৪ ঘণ্টার মধ্যে আমাদের কাস্টমার কেয়ারে যোগাযোগ করুন। আমরা সম্পূর্ণ ফ্রিতে পণ্য পরিবর্তন বা রিফান্ড করে দেবো।'
    }
  ];

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
      <div className="border-t border-stone-200/80 dark:border-neutral-800 pt-4 sm:pt-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Left Side: Institutional Trust Pillars */}
          <div className="lg:col-span-7 space-y-3 sm:space-y-4">
            <div>
              <p className="text-xs font-medium text-brand-emerald dark:text-emerald-400 mb-0.5">আমাদের অঙ্গীকার</p>
              <h2 className={TYPOGRAPHY_TOKENS.sectionTitle}>কেন দেশি মার্ট থেকে কেনাকাটা করবেন?</h2>
              <p className="text-xs sm:text-sm text-stone-500 dark:text-stone-400 mt-0.5">
                গুণগত মান, স্বচ্ছ মূল্য এবং গ্রাহক সন্তুষ্টিই আমাদের প্রধান লক্ষ্য
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {trustItems.map((item) => (
                <div 
                  key={item.id}
                  className="p-3 sm:p-4 rounded-lg bg-white dark:bg-[#121316] border border-stone-200/80 dark:border-neutral-800"
                >
                  <div className="w-8 h-8 rounded-md bg-brand-emerald/8 dark:bg-emerald-500/10 flex items-center justify-center mb-2">
                    {item.icon}
                  </div>
                  <h3 className="text-sm font-semibold text-stone-900 dark:text-stone-100 mb-1 leading-5">
                    {item.title}
                  </h3>
                  <p className="text-xs text-stone-500 dark:text-stone-400 leading-4">
                    {item.description}
                  </p>
                </div>
              ))}
            </div>

            <div className="pt-1 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-stone-500 dark:text-stone-400">
              <span className="font-semibold text-stone-700 dark:text-stone-300">সমর্থিত পেমেন্ট মাধ্যম:</span>
              <span>বিকাশ</span>
              <span aria-hidden="true">·</span>
              <span>নগদ</span>
              <span aria-hidden="true">·</span>
              <span>রকেট</span>
              <span aria-hidden="true">·</span>
              <span>ভিসা ও মাস্টারকার্ড</span>
              <span aria-hidden="true">·</span>
              <span>ক্যাশ অন ডেলিভারি</span>
            </div>
          </div>

          {/* Right Side: FAQ Accordions */}
          <div className="lg:col-span-5 space-y-3 sm:space-y-4">
            <div>
              <p className="text-xs font-medium text-brand-emerald dark:text-emerald-400 mb-0.5">সহায়িকা</p>
              <h2 className={TYPOGRAPHY_TOKENS.sectionTitle}>সাধারণ জিজ্ঞাসাসমূহ</h2>
              <p className="text-xs sm:text-sm text-stone-500 dark:text-stone-400 mt-0.5">
                অর্ডার ও ডেলিভারি সংক্রান্ত সচরাচর জিজ্ঞাসিত প্রশ্নের উত্তর
              </p>
            </div>

            <div className="space-y-2">
              {faqs.map((faq, idx) => {
                const isOpen = openIndex === idx;
                return (
                  <div 
                    key={idx}
                    className="rounded-lg border border-stone-200/80 dark:border-neutral-800 bg-white dark:bg-[#121316] overflow-hidden"
                  >
                    <button
                      type="button"
                      onClick={() => toggleFaq(idx)}
                      aria-expanded={isOpen}
                      className="w-full px-4 py-3 flex items-center justify-between text-left gap-3 focus:outline-none cursor-pointer"
                    >
                      <span className="text-sm font-medium text-stone-900 dark:text-stone-100 leading-5">
                        {faq.question}
                      </span>
                      <motion.div
                        animate={{ rotate: isOpen ? 180 : 0 }}
                        transition={{ duration: 0.15 }}
                        className="text-stone-400 shrink-0"
                      >
                        <ChevronDown size={14} />
                      </motion.div>
                    </button>

                    <AnimatePresence initial={false}>
                      {isOpen && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.15, ease: 'easeOut' }}
                        >
                          <div className="px-4 pb-3 pt-2 text-xs sm:text-sm text-stone-600 dark:text-stone-300 leading-5 border-t border-stone-100 dark:border-neutral-800">
                            {faq.answer}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
