import React from 'react';
import { features } from '../data';
import * as Icons from 'lucide-react';

export function Features() {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2 sm:py-3">
      <div className="bg-white dark:bg-[#121316] rounded-xl border border-stone-200/80 dark:border-neutral-800 p-3 sm:p-4">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 lg:divide-x lg:divide-stone-200/70 dark:lg:divide-neutral-800">
          {features.map((feature, index) => {
            const Icon = Icons[feature.icon as keyof typeof Icons] as React.ElementType;
            return (
              <div
                key={feature.id}
                className={`flex items-start sm:items-center gap-3 ${index !== 0 ? 'lg:pl-4' : ''}`}
              >
                <div className="w-8 h-8 rounded-lg bg-brand-emerald/8 dark:bg-emerald-500/10 text-brand-emerald dark:text-emerald-400 flex items-center justify-center shrink-0">
                  {Icon && <Icon size={16} strokeWidth={1.75} />}
                </div>
                <div className="min-w-0">
                  <h3 className="font-sans font-semibold text-stone-900 dark:text-stone-100 text-sm leading-5 truncate">
                    {feature.title}
                  </h3>
                  <p className="text-stone-500 dark:text-stone-400 text-xs leading-4 truncate">
                    {feature.subtitle}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
