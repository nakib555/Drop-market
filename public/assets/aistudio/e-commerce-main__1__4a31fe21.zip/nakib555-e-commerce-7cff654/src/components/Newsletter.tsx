import React, { useState } from 'react';
import { Mail, Check } from 'lucide-react';
import { TYPOGRAPHY_TOKENS } from '../theme';

export function Newsletter() {
  const [submitted, setSubmitted] = useState(false);
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubmitted(true);
      setEmail('');
    }
  };

  return (
    <section className="bg-white dark:bg-[#121315] border-t border-stone-200/80 dark:border-neutral-800 py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start sm:items-center gap-3 flex-1">
          <div className="w-9 h-9 rounded-lg bg-brand-emerald/10 dark:bg-emerald-500/10 flex items-center justify-center text-brand-emerald dark:text-emerald-400 shrink-0">
            <Mail size={16} strokeWidth={1.75} />
          </div>
          <div>
            <h2 className={`${TYPOGRAPHY_TOKENS.sectionTitle} mb-0.5`}>
              নতুন কালেকশন ও অফার আপডেট পান
            </h2>
            <p className="text-stone-500 dark:text-stone-400 text-xs sm:text-sm leading-5">
              আপনার ই-মেইল যুক্ত করুন এবং মৌসুমী মূল্যছাড় ও নতুন পণ্যের খবর সবার আগে জানুন।
            </p>
          </div>
        </div>

        <div className="w-full md:w-auto md:min-w-[360px]">
          {submitted ? (
            <div className="flex items-center gap-2 text-sm font-medium text-brand-emerald dark:text-emerald-400 bg-brand-emerald/8 px-3 py-2 rounded-lg">
              <Check size={15} />
              <span>ধন্যবাদ! আপনার ই-মেইল সফলভাবে যুক্ত হয়েছে।</span>
            </div>
          ) : (
            <form
              onSubmit={handleSubmit}
              className="flex w-full gap-2"
            >
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="আপনার ই-মেইল ঠিকানা লিখুন..." 
                aria-label="ই-মেইল ঠিকানা"
                className="flex-1 h-9 px-3 text-sm rounded-lg border border-stone-200 dark:border-neutral-800 focus:outline-none focus:border-brand-emerald text-stone-800 dark:text-white bg-stone-50 dark:bg-neutral-900"
                required
              />
              <button 
                type="submit" 
                className="h-9 bg-brand-emerald text-white px-4 font-medium hover:bg-brand-dark rounded-lg transition-colors cursor-pointer text-xs sm:text-sm whitespace-nowrap"
              >
                সাবস্ক্রাইব
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
