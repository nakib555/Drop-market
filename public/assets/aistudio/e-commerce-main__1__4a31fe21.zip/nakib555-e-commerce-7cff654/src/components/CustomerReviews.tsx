import React from 'react';
import { Star } from 'lucide-react';
import { TYPOGRAPHY_TOKENS } from '../theme';

interface Review {
  id: string;
  name: string;
  role: string;
  avatar: string;
  rating: number;
  comment: string;
  date: string;
  product: string;
}

export function CustomerReviews() {
  const reviews: Review[] = [
    {
      id: '1',
      name: 'হাসান আল মামুন',
      role: 'ভেরিফাইড ক্রেতা, ঢাকা',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=100&h=100',
      rating: 5,
      comment: 'এদের পাঞ্জাবিগুলোর কটন কোয়ালিটি আসলেই দারুণ। ঈদের পাঞ্জাবিটা কিনে খুবই সন্তুষ্ট, কাপড় অনেক আরামদায়ক এবং সেলাই নিখুঁত।',
      date: '৩ দিন আগে',
      product: 'প্রিমিয়াম কটন পাঞ্জাবি'
    },
    {
      id: '2',
      name: 'নুসরাত জাহান',
      role: 'ভেরিফাইড ক্রেতা, চট্টগ্রাম',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=100&h=100',
      rating: 5,
      comment: 'জামদানী শাড়িটা হাতে পেয়েছি। কালারটা ছবিতে যেমন ছিল একদম তেমনই পেয়েছি। নির্ধারিত সময়ের মধ্যে ডেলিভারি দেয়ার জন্য ধন্যবাদ।',
      date: '১ সপ্তাহ আগে',
      product: 'জামদানী শাড়ি'
    },
    {
      id: '3',
      name: 'তাহমিদ আহমেদ',
      role: 'ভেরিফাইড ক্রেতা, সিলেট',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=100&h=100',
      rating: 5,
      comment: 'ঘড়িটি খুবই চমৎকার ও দেখতে প্রিমিয়াম লুক দেয়। প্যাকেজিং এবং বিক্রয়োত্তর সেবা সত্যিই প্রশংসনীয়।',
      date: '২ সপ্তাহ আগে',
      product: 'লাক্সারি মেনস ওয়াচ'
    },
  ];

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
      <div className="mb-3 sm:mb-4">
        <p className="text-xs font-medium text-brand-emerald dark:text-emerald-400 mb-0.5">গ্রাহক অভিজ্ঞতা</p>
        <h2 className={TYPOGRAPHY_TOKENS.sectionTitle}>ক্রেতাদের মতামত ও রিভিউ</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 sm:gap-4">
        {reviews.map((review) => (
          <article 
            key={review.id}
            className="bg-white dark:bg-[#121316] p-4 rounded-xl border border-stone-200/80 dark:border-neutral-800 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center gap-1 mb-2">
                {Array(5).fill(0).map((_, i) => (
                  <Star 
                    key={i} 
                    size={12} 
                    className={`${i < review.rating ? 'text-amber-500 fill-amber-500' : 'text-stone-200 dark:text-neutral-700'}`} 
                  />
                ))}
              </div>
              <p className="text-xs sm:text-sm text-stone-700 dark:text-stone-300 leading-5 mb-3">
                “{review.comment}”
              </p>
            </div>

            <div className="flex items-center gap-2.5 pt-3 border-t border-stone-100 dark:border-neutral-800">
              <img 
                src={review.avatar} 
                alt={review.name}
                referrerPolicy="no-referrer"
                className="w-8 h-8 rounded-full object-cover border border-stone-200 dark:border-neutral-700"
              />
              <div className="flex-1 min-w-0">
                <h3 className="text-sm font-semibold text-stone-900 dark:text-stone-100 truncate">
                  {review.name}
                </h3>
                <div className="flex items-center gap-1.5 text-xs text-stone-500 dark:text-stone-400 truncate">
                  <span className="text-brand-emerald dark:text-emerald-400 font-medium truncate">{review.product}</span>
                  <span aria-hidden="true">·</span>
                  <span className="shrink-0">{review.date}</span>
                </div>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
