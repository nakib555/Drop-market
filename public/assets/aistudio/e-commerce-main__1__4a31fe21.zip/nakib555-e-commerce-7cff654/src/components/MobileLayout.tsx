import React, { useState, useEffect } from 'react';
import { Product } from '../types';
import { Hero } from './Hero';
import { CategoryList } from './CategoryList';
import { FlashSale } from './FlashSale';
import { BestSellers } from './BestSellers';
import { NewArrivals } from './NewArrivals';
import { Brands } from './Brands';
import { CustomerReviews } from './CustomerReviews';
import { Features } from './Features';
import { TrustAndFaq } from './TrustAndFaq';
import { Newsletter } from './Newsletter';
import { Footer } from './Footer';
import { groceryCategories, groceryProducts, groceryBrands } from '../data';

const ProductSkeleton = () => (
  <div className="border border-slate-100 dark:border-gray-800/60 rounded-[1.25rem] overflow-hidden relative p-2.5 bg-white dark:bg-[#1A1A1A] shadow-sm">
    <div className="w-full h-24 shimmer rounded-xl mb-3"></div>
    <div className="h-3 shimmer rounded w-3/4 mb-2"></div>
    <div className="h-4 shimmer rounded w-1/2 mb-3"></div>
    <div className="flex justify-between items-center mt-auto">
      <div className="h-3 shimmer rounded w-1/3"></div>
      <div className="w-7 h-7 shimmer rounded-full"></div>
    </div>
  </div>
);

const GrocerySkeleton = () => (
  <div className="min-w-[140px] border border-slate-100 dark:border-gray-800/60 rounded-[1.5rem] bg-white dark:bg-[#1A1A1A] p-2.5 relative flex flex-col shadow-sm">
    <div className="h-28 w-full shimmer rounded-[1.25rem] mb-3"></div>
    <div className="h-3 shimmer rounded w-3/4 mb-1.5"></div>
    <div className="h-2 shimmer rounded w-1/3 mb-3"></div>
    <div className="mt-auto flex items-end justify-between">
      <div className="h-4 shimmer rounded w-1/2"></div>
      <div className="w-7 h-7 shimmer rounded-xl"></div>
    </div>
  </div>
);

const ListItemSkeleton = () => (
  <div className="flex items-center justify-between p-2 -mx-2 rounded-[1.25rem] bg-white dark:bg-[#1A1A1A] mb-2 border border-slate-50 dark:border-gray-800/40 shadow-sm">
    <div className="flex items-center gap-4 w-full">
      <div className="w-[85px] h-[85px] shimmer rounded-xl flex-shrink-0"></div>
      <div className="flex flex-col w-full">
        <div className="h-3.5 shimmer rounded w-2/3 mb-2"></div>
        <div className="h-4 shimmer rounded w-1/3 mb-2"></div>
        <div className="h-3 shimmer rounded w-1/4"></div>
      </div>
    </div>
    <div className="w-11 h-11 rounded-full shimmer flex-shrink-0 ml-2"></div>
  </div>
);

interface MobileLayoutProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  cartCount: number;
  onCartClick: () => void;
  children?: React.ReactNode;
  currentSeason?: string;
  onProductClick?: (product: Product) => void;
  onAddToCart?: (product: Product, quantity: number) => void;
}

export function MobileLayout({
  activeTab,
  onTabChange,
  cartCount,
  onCartClick,
  children,
  currentSeason = 'default',
  onProductClick,
  onAddToCart
}: MobileLayoutProps) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isCategoriesSubmenuOpen, setIsCategoriesSubmenuOpen] = useState(false);
  const [activeView, setActiveView] = useState<'fashion' | 'grocery'>('fashion');
  const [sidebarLang, setSidebarLang] = useState<'en' | 'bn'>('en');
  const [isLoading, setIsLoading] = useState(true);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [groceryActiveSlide, setGroceryActiveSlide] = useState(0);

  const GROCERY_SLIDES = [
    {
      badge: "New Collection",
      title: "Premium Quality Everyday Essentials",
      tagline: "Discover the best products for you and your family",
      image: "https://images.unsplash.com/photo-1542838132-92c53300491e?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80",
      bgClass: "bg-amber-50/60 border-amber-100/30 text-slate-900",
      badgeTextClass: "text-primary",
      btnClass: "bg-primary hover:bg-brand-dark",
      badgeIconClass: "ph-fill ph-leaf text-brand-emerald",
    },
    {
      badge: "Farm Fresh",
      title: "Fresh Organic Fruits & Veggies",
      tagline: "Direct from farms to your dining table within 24 hours",
      image: "https://images.unsplash.com/photo-1583258292688-d0213dc5a3a8?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80",
      bgClass: "bg-emerald-50/60 border-emerald-100/30 text-emerald-950",
      badgeTextClass: "text-emerald-700",
      btnClass: "bg-emerald-600 hover:bg-emerald-700",
      badgeIconClass: "ph-fill ph-carrot text-emerald-600",
    },
    {
      badge: "Pure Quality",
      title: "Pure & Premium Grocery Items",
      tagline: "Assured quality and 100% authenticity on daily needs",
      image: "https://images.unsplash.com/photo-1543083503-0c40dac3eb30?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80",
      bgClass: "bg-cyan-50/60 border-cyan-100/30 text-cyan-950",
      badgeTextClass: "text-cyan-700",
      btnClass: "bg-cyan-600 hover:bg-cyan-700",
      badgeIconClass: "ph-fill ph-shield-check text-cyan-600",
    },
    {
      badge: "Mega Discount",
      title: "Super Saving Family Combos",
      tagline: "Huge discounts and special family grocery bundles",
      image: "https://images.unsplash.com/photo-1549465220-1a8b9238cd48?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80",
      bgClass: "bg-rose-50/60 border-rose-100/30 text-rose-950",
      badgeTextClass: "text-rose-700",
      btnClass: "bg-rose-600 hover:bg-rose-700",
      badgeIconClass: "ph-fill ph-gift text-rose-600",
    }
  ];

  // Auto-slide grocery banner every 5s
  useEffect(() => {
    const timer = setInterval(() => {
      setGroceryActiveSlide(prev => (prev + 1) % GROCERY_SLIDES.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [GROCERY_SLIDES.length]);
  
  const [openAccordion, setOpenAccordion] = useState<string | null>(null);

  // Delivery Location state management
  const [deliveryLocation, setDeliveryLocation] = useState<string>(() => {
    try {
      return localStorage.getItem('deliveryLocation') || 'ঢাকা, বাংলাদেশ';
    } catch (e) {
      return 'ঢাকা, বাংলাদেশ';
    }
  });
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);
  const [isDetectingLocation, setIsDetectingLocation] = useState(false);
  const [manualLocationInput, setManualLocationInput] = useState('');
  const [locationError, setLocationError] = useState<string | null>(null);

  const popularCities = [
    { name: 'ঢাকা', en: 'Dhaka' },
    { name: 'চট্টগ্রাম', en: 'Chittagong' },
    { name: 'সিলেট', en: 'Sylhet' },
    { name: 'রাজশাহী', en: 'Rajshahi' },
    { name: 'খুলনা', en: 'Khulna' },
    { name: 'বরিশাল', en: 'Barishal' },
    { name: 'রংপুর', en: 'Rangpur' },
    { name: 'ময়মনসিংহ', en: 'Mymensingh' }
  ];

  const handleUseCurrentLocation = () => {
    if (!navigator.geolocation) {
      setLocationError('আপনার ব্রাউজারটি জিপিএস লোকেশন সমর্থন করে না।');
      return;
    }

    setIsDetectingLocation(true);
    setLocationError(null);

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        try {
          // Real reverse geocoding with Nominatim API (OpenStreetMap)
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&accept-language=bn`
          );
          if (!response.ok) throw new Error('Network response was not ok');
          const data = await response.json();
          if (data && data.address) {
            const address = data.address;
            const road = address.road || '';
            const villageOrSuburb = address.village || address.suburb || address.neighbourhood || address.residential || '';
            const city = address.city || address.town || address.state_district || address.state || '';
            
            let formattedAddress = '';
            if (road) {
              formattedAddress += road + ', ';
            }
            if (villageOrSuburb) {
              formattedAddress += villageOrSuburb + ', ';
            }
            if (city) {
              formattedAddress += city;
            }

            // Fallback to display_name slice if we got an empty string
            if (!formattedAddress.trim()) {
              formattedAddress = data.display_name.split(',').slice(0, 3).join(',').trim();
            }

            // Remove trailing commas
            formattedAddress = formattedAddress.replace(/,\s*$/, "");

            if (formattedAddress) {
              setDeliveryLocation(formattedAddress);
              localStorage.setItem('deliveryLocation', formattedAddress);
              setIsLocationModalOpen(false);
            } else {
              const fallbackStr = `জিপিএস পজিশন (${latitude.toFixed(3)}, ${longitude.toFixed(3)})`;
              setDeliveryLocation(fallbackStr);
              localStorage.setItem('deliveryLocation', fallbackStr);
              setIsLocationModalOpen(false);
            }
          } else {
            const fallbackStr = `জিপিএস পজিশন (${latitude.toFixed(3)}, ${longitude.toFixed(3)})`;
            setDeliveryLocation(fallbackStr);
            localStorage.setItem('deliveryLocation', fallbackStr);
            setIsLocationModalOpen(false);
          }
        } catch (err) {
          console.error(err);
          // Fallback if API fails or blocks
          const fallbackStr = `ঢাকা (${latitude.toFixed(3)}, ${longitude.toFixed(3)})`;
          setDeliveryLocation(fallbackStr);
          localStorage.setItem('deliveryLocation', fallbackStr);
          setIsLocationModalOpen(false);
        } finally {
          setIsDetectingLocation(false);
        }
      },
      (error) => {
        setIsDetectingLocation(false);
        switch (error.code) {
          case error.PERMISSION_DENIED:
            setLocationError('লোকেশনের অনুমতি দেওয়া হয়নি। অনুগ্রহ করে ব্রাউজারে অনুমতি দিন।');
            break;
          case error.POSITION_UNAVAILABLE:
            setLocationError('লোকেশন তথ্য পাওয়া যায়নি।');
            break;
          case error.TIMEOUT:
            setLocationError('লোকেশন রিকোয়েস্টের সময় শেষ হয়ে গেছে।');
            break;
          default:
            setLocationError('লোকেশন নির্ধারণে সমস্যা হয়েছে।');
            break;
        }
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const handleManualLocationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualLocationInput.trim()) {
      setDeliveryLocation(manualLocationInput.trim());
      localStorage.setItem('deliveryLocation', manualLocationInput.trim());
      setIsLocationModalOpen(false);
      setManualLocationInput('');
    }
  };

  const selectPopularCity = (cityName: string) => {
    setDeliveryLocation(cityName);
    localStorage.setItem('deliveryLocation', cityName);
    setIsLocationModalOpen(false);
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 250);
    return () => clearTimeout(timer);
  }, []);
  
  const toggleAccordion = (id: string) => {
    setOpenAccordion(prev => prev === id ? null : id);
  };

  const closeSidebar = () => setIsSidebarOpen(false);
  const openSidebar = () => setIsSidebarOpen(true);

  useEffect(() => {
    if (isSidebarOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isSidebarOpen]);

  const switchCategoryView = (category: 'fashion' | 'grocery') => {
    setActiveView(category);
    onTabChange('home');
    closeSidebar();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSidebarNav = (tab: string, sectionId?: string) => {
    onTabChange(tab);
    closeSidebar();
    if (sectionId) {
      setTimeout(() => {
        const el = document.getElementById(sectionId);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 150);
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div className="text-stone-900 antialiased bg-brand-light md:hidden font-bilingual">
      {/* OVERLAY FOR SIDEBAR */}
      <div 
        className={`fixed inset-0 bg-slate-950/55 z-[60] transition-opacity duration-300 cursor-pointer backdrop-blur-[2px] ${isSidebarOpen ? 'opacity-100' : 'opacity-0 pointer-events-none hidden'}`}
        onClick={closeSidebar}
      />

      {/* MAIN SIDEBAR (DRAWER) — 8pt Grid & Small Modular Type Scale (Linear / shadcn/ui) */}
      <aside 
        aria-label="প্রধান সাইডবার মেনু"
        className={`fixed top-0 left-0 h-full w-[86%] max-w-[312px] bg-[#0D6843] z-[70] transform transition-transform duration-300 cubic-bezier(0.16, 1, 0.3, 1) flex flex-col font-bilingual rounded-r-2xl overflow-hidden shadow-[0_16px_48px_rgba(0,0,0,0.24)] ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        {/* Top Deep Emerald Profile & Store Header (8pt grid: pt-6 pb-6 px-4 = 24px/16px) */}
        <div className="bg-gradient-to-b from-[#0E6E47] to-[#0B5939] pt-6 pb-6 px-4 relative shrink-0">
          {/* Top-Right Controls: EN / বাংলা Language Button + Close Button (8pt grid: top-3 right-3 gap-1.5) */}
          <div className="absolute top-3 right-3 flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setSidebarLang(prev => (prev === 'en' ? 'bn' : 'en'))}
              className="h-7 bg-white/14 hover:bg-white/22 text-white text-xs font-semibold px-2.5 rounded-lg border border-white/20 transition-colors cursor-pointer tracking-tight flex items-center justify-center"
              title="Switch Sidebar Language (English / বাংলা)"
            >
              {sidebarLang === 'en' ? 'বাংলা' : 'EN'}
            </button>
            <button
              type="button"
              onClick={closeSidebar}
              aria-label="Close sidebar"
              className="w-7 h-7 text-white/90 hover:text-white transition rounded-lg hover:bg-white/10 flex items-center justify-center cursor-pointer"
            >
              <i className="ph ph-x text-base"></i>
            </button>
          </div>
          
          {/* Profile Info Row (8pt grid: 40px w-10 h-10 avatar, gap-3 = 12px) */}
          <div className="flex items-center gap-3 pr-16">
            <div className="relative shrink-0 w-10 h-10 rounded-full flex items-center justify-center bg-white/15 border border-white/80 p-0.5 shadow-xs">
              <img 
                src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80" 
                alt="Tahmina Islam" 
                className="w-full h-full rounded-full object-cover" 
              />
            </div>
            <div className="flex flex-col min-w-0">
              <h3 className="text-white font-heading font-semibold text-sm sm:text-base leading-tight tracking-tight truncate">
                {sidebarLang === 'en' ? 'Tahmina Islam' : 'তাহমিনা ইসলাম'}
              </h3>
              <p className="text-emerald-50/85 text-xs mt-0.5 font-normal tracking-normal truncate">
                tahmina.islam@email.com
              </p>
            </div>
          </div>

          {/* Store Selector Card Inside Emerald Header (8pt grid: mt-3 p-2.5 rounded-xl, w-9 h-9 icon) */}
          <div
            onClick={() => switchCategoryView(activeView === 'fashion' ? 'grocery' : 'fashion')}
            className="mt-3 bg-white rounded-xl p-2.5 flex items-center justify-between shadow-sm cursor-pointer border border-white/90 group transition-transform active:scale-[0.99]"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-9 h-9 rounded-lg bg-[#E8F6EF] border border-[#CBEAD9] flex items-center justify-center text-[#0D6843] shrink-0 group-hover:bg-[#0D6843] group-hover:text-white transition-colors duration-200">
                <i className="ph ph-shopping-bag-open text-lg"></i>
              </div>
              <div className="flex flex-col min-w-0">
                <h4 className="text-[13px] font-heading font-semibold text-slate-900 leading-tight tracking-tight truncate">
                  {activeView === 'grocery'
                    ? (sidebarLang === 'en' ? 'Rahmaniya Mart' : 'রহমানিয়া মার্ট')
                    : (sidebarLang === 'en' ? 'DeshiMart Lifestyle' : 'দেশিমার্ট লাইফস্টাইল')}
                </h4>
                <span className="text-[11px] font-medium text-[#0D6843] bg-[#E8F6EF] px-2 py-0.5 rounded-md inline-flex items-center gap-1 w-fit mt-1 leading-none">
                  <i className="ph-fill ph-crown text-amber-500 text-[11px]"></i>
                  <span>{sidebarLang === 'en' ? 'Premium Member' : 'প্রিমিয়াম মেম্বার'}</span>
                </span>
              </div>
            </div>
            <i className="ph ph-caret-right text-slate-400 group-hover:text-[#0D6843] group-hover:translate-x-0.5 transition-all text-sm shrink-0"></i>
          </div>
        </div>

        {/* Scrollable White Sheet Body (8pt grid: -mt-3 rounded-t-2xl pt-3 pb-6 px-3) */}
        <div className="-mt-3 rounded-t-2xl flex-1 overflow-y-auto no-scrollbar bg-white pt-3 pb-6 px-3 relative z-10">
          
          {/* Become Premium Promo Card (8pt grid: p-3 mb-3 rounded-xl) */}
          <div className="bg-gradient-to-br from-[#F3F7F5] via-[#F7F9F8] to-[#E8F3EE] rounded-xl p-3 flex items-center justify-between mb-3 border border-emerald-950/8 shadow-2xs relative overflow-hidden">
            <div className="w-[70%] z-10">
              <h4 className="text-[13px] font-heading font-semibold text-slate-900 tracking-tight mb-0.5">
                {sidebarLang === 'en' ? 'Become Premium' : 'প্রিমিয়াম মেম্বার হন'}
              </h4>
              <p className="text-xs text-slate-500 font-normal leading-snug mb-2.5">
                {sidebarLang === 'en'
                  ? 'Free delivery, extra discounts & perks'
                  : 'ফ্রি ডেলিভারি, অতিরিক্ত মূল্যছাড় ও সুবিধা'}
              </p>
              <button
                type="button"
                onClick={() => handleSidebarNav('profile')}
                className="h-7 bg-[#0D6843] hover:bg-[#094D31] transition-colors text-white text-xs font-semibold px-3 rounded-lg inline-flex items-center gap-1.5 shadow-2xs cursor-pointer"
              >
                <span>{sidebarLang === 'en' ? 'Upgrade Now' : 'আপগ্রেড করুন'}</span>
                <i className="ph ph-arrow-right text-xs"></i>
              </button>
            </div>
            <img
              src="https://cdn-icons-png.flaticon.com/512/4213/4213958.png"
              className="w-14 h-14 object-contain drop-shadow-xs z-10 shrink-0"
              alt="Premium Gift"
            />
          </div>

          {/* Primary Navigation List (8pt grid: h-9 = 36px rows, px-3 = 12px, gap-0.5, rounded-lg) */}
          <nav className="flex flex-col gap-0.5">
            {/* Home */}
            <button
              type="button"
              onClick={() => handleSidebarNav('home')}
              className={`w-full h-9 flex items-center justify-between px-3 rounded-lg transition-colors cursor-pointer group ${
                activeTab === 'home'
                  ? 'bg-[#ECF7F1] text-[#0D6843]'
                  : 'hover:bg-slate-100/80 text-slate-700 hover:text-[#0D6843]'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <i className={`ph ph-house text-[17px] ${activeTab === 'home' ? 'text-[#0D6843]' : 'text-slate-500 group-hover:text-[#0D6843]'}`}></i>
                <span className={`text-[13px] tracking-[-0.01em] ${activeTab === 'home' ? 'font-semibold text-[#0D6843]' : 'font-medium text-slate-800'}`}>
                  {sidebarLang === 'en' ? 'Home' : 'হোম'}
                </span>
              </div>
              <i className={`ph ph-caret-right text-xs ${activeTab === 'home' ? 'text-[#0D6843]' : 'text-slate-400 group-hover:text-[#0D6843]'}`}></i>
            </button>

            {/* All Categories (Expandable Accordion) */}
            <div className="flex flex-col">
              <button 
                type="button"
                onClick={() => setIsCategoriesSubmenuOpen(!isCategoriesSubmenuOpen)}
                className={`w-full h-9 flex items-center justify-between px-3 rounded-lg transition-colors cursor-pointer group outline-none ${
                  activeTab === 'categories'
                    ? 'bg-[#ECF7F1] text-[#0D6843]'
                    : 'hover:bg-slate-100/80 text-slate-800 hover:text-[#0D6843]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <i className="ph ph-squares-four text-[17px] text-slate-500 group-hover:text-[#0D6843] transition-colors"></i>
                  <span className="text-[13px] font-medium tracking-[-0.01em]">
                    {sidebarLang === 'en' ? 'All Categories' : 'সকল ক্যাটাগরি'}
                  </span>
                </div>
                <i className={`ph ph-caret-right text-xs transition-transform duration-200 ${isCategoriesSubmenuOpen ? 'rotate-90 text-[#0D6843]' : 'text-slate-400 group-hover:text-[#0D6843]'}`}></i>
              </button>
              
              <div className={`grid transition-all duration-200 ease-out ml-4 ${isCategoriesSubmenuOpen ? 'grid-rows-[1fr] opacity-100 mt-0.5 py-0.5' : 'grid-rows-[0fr] opacity-0'}`}>
                <div className="min-h-0 flex flex-col pl-3 pr-1 gap-0.5 border-l border-slate-200/80 overflow-hidden">
                  <button 
                    type="button"
                    onClick={() => switchCategoryView('fashion')}
                    className={`h-8 flex items-center justify-between px-2.5 rounded-lg transition-colors cursor-pointer ${
                      activeView === 'fashion'
                        ? 'bg-[#ECF7F1] text-[#0D6843] font-semibold'
                        : 'hover:bg-slate-100/80 text-slate-600 hover:text-[#0D6843] font-medium'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <i className="ph ph-coat-hanger text-[15px]"></i>
                      <span className="text-xs">
                        {sidebarLang === 'en' ? 'Fashion & Apparel' : 'ফ্যাশন ও পোশাক'}
                      </span>
                    </div>
                    <i className="ph ph-caret-right text-[11px] opacity-75"></i>
                  </button>

                  <button 
                    type="button"
                    onClick={() => switchCategoryView('grocery')}
                    className={`h-8 flex items-center justify-between px-2.5 rounded-lg transition-colors cursor-pointer ${
                      activeView === 'grocery'
                        ? 'bg-[#ECF7F1] text-[#0D6843] font-semibold'
                        : 'hover:bg-slate-100/80 text-slate-600 hover:text-[#0D6843] font-medium'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <i className="ph ph-carrot text-[15px] text-emerald-600"></i>
                      <span className="text-xs">
                        {sidebarLang === 'en' ? 'Grocery & Food' : 'গ্রোসারি ও ফুড'}
                      </span>
                    </div>
                    <i className="ph ph-caret-right text-[11px] opacity-75"></i>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleSidebarNav('categories')}
                    className="h-8 flex items-center justify-between px-2.5 rounded-lg hover:bg-slate-100/80 text-xs font-medium text-slate-600 hover:text-[#0D6843] transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <i className="ph ph-baby text-[15px] text-rose-500"></i>
                      <span>{sidebarLang === 'en' ? 'Baby & Kids' : 'বেবি ও কিডস'}</span>
                    </div>
                    <i className="ph ph-caret-right text-[11px] text-slate-400"></i>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleSidebarNav('categories')}
                    className="h-8 flex items-center justify-between px-2.5 rounded-lg hover:bg-slate-100/80 text-xs font-medium text-slate-600 hover:text-[#0D6843] transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <i className="ph ph-pencil-line text-[15px] text-blue-500"></i>
                      <span>{sidebarLang === 'en' ? 'Books & Stationery' : 'বই ও স্টেশনারি'}</span>
                    </div>
                    <i className="ph ph-caret-right text-[11px] text-slate-400"></i>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleSidebarNav('categories')}
                    className="h-8 flex items-center justify-between px-2.5 rounded-lg hover:bg-slate-100/80 text-xs font-medium text-slate-600 hover:text-[#0D6843] transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <i className="ph ph-paw-print text-[15px] text-amber-500"></i>
                      <span>{sidebarLang === 'en' ? 'Pet Supplies' : 'পেট সাপ্লাইজ'}</span>
                    </div>
                    <i className="ph ph-caret-right text-[11px] text-slate-400"></i>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleSidebarNav('categories')}
                    className="h-8 flex items-center justify-between px-2.5 rounded-lg hover:bg-slate-100/80 text-xs font-medium text-slate-600 hover:text-[#0D6843] transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <i className="ph ph-devices text-[15px] text-indigo-500"></i>
                      <span>{sidebarLang === 'en' ? 'Digital Products' : 'ডিজিটাল পণ্য'}</span>
                    </div>
                    <i className="ph ph-caret-right text-[11px] text-slate-400"></i>
                  </button>
                </div>
              </div>
            </div>

            {/* Flash Sale */}
            <button
              type="button"
              onClick={() => handleSidebarNav('home', 'flash-sale')}
              className="w-full h-9 flex items-center justify-between px-3 rounded-lg hover:bg-slate-100/80 text-slate-800 hover:text-[#0D6843] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2.5">
                <i className="ph ph-lightning text-[17px] text-slate-500 group-hover:text-[#0D6843] transition-colors"></i>
                <span className="text-[13px] font-medium tracking-[-0.01em] flex items-center gap-2">
                  <span>{sidebarLang === 'en' ? 'Flash Sale' : 'ফ্ল্যাশ সেল'}</span>
                  <span className="bg-[#FF4626] text-white text-[10px] font-semibold px-2 py-0.5 rounded-md leading-tight">
                    {sidebarLang === 'en' ? 'Hot' : 'হট'}
                  </span>
                </span>
              </div>
              <i className="ph ph-caret-right text-xs text-slate-400 group-hover:text-[#0D6843] transition"></i>
            </button>

            {/* New Arrivals */}
            <button
              type="button"
              onClick={() => handleSidebarNav('home')}
              className="w-full h-9 flex items-center justify-between px-3 rounded-lg hover:bg-slate-100/80 text-slate-800 hover:text-[#0D6843] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2.5">
                <i className="ph ph-tag text-[17px] text-slate-500 group-hover:text-[#0D6843] transition-colors"></i>
                <span className="text-[13px] font-medium tracking-[-0.01em]">
                  {sidebarLang === 'en' ? 'New Arrivals' : 'নতুন কালেকশন'}
                </span>
              </div>
              <i className="ph ph-caret-right text-xs text-slate-400 group-hover:text-[#0D6843] transition"></i>
            </button>

            {/* Best Selling */}
            <button
              type="button"
              onClick={() => handleSidebarNav('home', 'featured-collection')}
              className="w-full h-9 flex items-center justify-between px-3 rounded-lg hover:bg-slate-100/80 text-slate-800 hover:text-[#0D6843] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2.5">
                <i className="ph ph-star text-[17px] text-slate-500 group-hover:text-[#0D6843] transition-colors"></i>
                <span className="text-[13px] font-medium tracking-[-0.01em]">
                  {sidebarLang === 'en' ? 'Best Selling' : 'সেরা বিক্রিত'}
                </span>
              </div>
              <i className="ph ph-caret-right text-xs text-slate-400 group-hover:text-[#0D6843] transition"></i>
            </button>

            {/* Top Brands */}
            <button
              type="button"
              onClick={() => handleSidebarNav('home')}
              className="w-full h-9 flex items-center justify-between px-3 rounded-lg hover:bg-slate-100/80 text-slate-800 hover:text-[#0D6843] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2.5">
                <i className="ph ph-shield-check text-[17px] text-slate-500 group-hover:text-[#0D6843] transition-colors"></i>
                <span className="text-[13px] font-medium tracking-[-0.01em]">
                  {sidebarLang === 'en' ? 'Top Brands' : 'জনপ্রিয় ব্র্যান্ড'}
                </span>
              </div>
              <i className="ph ph-caret-right text-xs text-slate-400 group-hover:text-[#0D6843] transition"></i>
            </button>

            {/* Offers */}
            <button
              type="button"
              onClick={() => handleSidebarNav('home', 'flash-sale')}
              className="w-full h-9 flex items-center justify-between px-3 rounded-lg hover:bg-slate-100/80 text-slate-800 hover:text-[#0D6843] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2.5">
                <i className="ph ph-seal-percent text-[17px] text-slate-500 group-hover:text-[#0D6843] transition-colors"></i>
                <span className="text-[13px] font-medium tracking-[-0.01em]">
                  {sidebarLang === 'en' ? 'Offers' : 'বিশেষ অফার'}
                </span>
              </div>
              <i className="ph ph-caret-right text-xs text-slate-400 group-hover:text-[#0D6843] transition"></i>
            </button>

            <div className="h-px bg-slate-100 my-1.5 mx-2"></div>

            {/* My Orders */}
            <button
              type="button"
              onClick={() => handleSidebarNav('orders')}
              className={`w-full h-9 flex items-center justify-between px-3 rounded-lg transition-colors cursor-pointer group ${
                activeTab === 'orders'
                  ? 'bg-[#ECF7F1] text-[#0D6843]'
                  : 'hover:bg-slate-100/80 text-slate-800 hover:text-[#0D6843]'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <i className="ph ph-package text-[17px] text-slate-500 group-hover:text-[#0D6843] transition-colors"></i>
                <span className="text-[13px] font-medium tracking-[-0.01em]">
                  {sidebarLang === 'en' ? 'My Orders' : 'আমার অর্ডার'}
                </span>
              </div>
              <i className="ph ph-caret-right text-xs text-slate-400 group-hover:text-[#0D6843] transition"></i>
            </button>

            {/* Wishlist */}
            <button
              type="button"
              onClick={() => handleSidebarNav('profile')}
              className="w-full h-9 flex items-center justify-between px-3 rounded-lg hover:bg-slate-100/80 text-slate-800 hover:text-[#0D6843] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2.5">
                <i className="ph ph-heart text-[17px] text-slate-500 group-hover:text-[#0D6843] transition-colors"></i>
                <span className="text-[13px] font-medium tracking-[-0.01em]">
                  {sidebarLang === 'en' ? 'Wishlist' : 'উইশলিস্ট'}
                </span>
              </div>
              <span className="w-5 h-5 rounded-md bg-[#0D6843] text-white text-[11px] font-semibold tabular-nums flex items-center justify-center">
                {sidebarLang === 'en' ? '4' : '৪'}
              </span>
            </button>

            {/* Compare */}
            <button
              type="button"
              onClick={() => handleSidebarNav('categories')}
              className="w-full h-9 flex items-center justify-between px-3 rounded-lg hover:bg-slate-100/80 text-slate-800 hover:text-[#0D6843] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-[17px] h-[17px] flex items-center justify-center text-slate-500 group-hover:text-[#0D6843] transition-colors">
                  <svg className="w-[16px] h-[16px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M7 15c0-1.2 1-2 2-2s2 .8 2 2-1 2-2 2H6M8 12.5V7C8 6 7.5 5.5 7 5.5" />
                    <path d="M12 9h5M17 9l-3-3M15 16h-5M10 16l3 3" />
                  </svg>
                </div>
                <span className="text-[13px] font-medium tracking-[-0.01em]">
                  {sidebarLang === 'en' ? 'Compare' : 'পণ্য তুলনা'}
                </span>
              </div>
              <i className="ph ph-caret-right text-xs text-slate-400 group-hover:text-[#0D6843] transition"></i>
            </button>

            {/* Track Order */}
            <button
              type="button"
              onClick={() => handleSidebarNav('orders')}
              className="w-full h-9 flex items-center justify-between px-3 rounded-lg hover:bg-slate-100/80 text-slate-800 hover:text-[#0D6843] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2.5">
                <i className="ph ph-truck text-[17px] text-slate-500 group-hover:text-[#0D6843] transition-colors"></i>
                <span className="text-[13px] font-medium tracking-[-0.01em]">
                  {sidebarLang === 'en' ? 'Track Order' : 'অর্ডার ট্র্যাকিং'}
                </span>
              </div>
              <i className="ph ph-caret-right text-xs text-slate-400 group-hover:text-[#0D6843] transition"></i>
            </button>

            <div className="h-px bg-slate-100 my-1.5 mx-2"></div>

            {/* Addresses */}
            <button
              type="button"
              onClick={() => handleSidebarNav('profile')}
              className="w-full h-9 flex items-center justify-between px-3 rounded-lg hover:bg-slate-100/80 text-slate-800 hover:text-[#0D6843] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2.5">
                <i className="ph ph-map-pin text-[17px] text-slate-500 group-hover:text-[#0D6843] transition-colors"></i>
                <span className="text-[13px] font-medium tracking-[-0.01em]">
                  {sidebarLang === 'en' ? 'Addresses' : 'ঠিকানাসমূহ'}
                </span>
              </div>
              <i className="ph ph-caret-right text-xs text-slate-400 group-hover:text-[#0D6843] transition"></i>
            </button>

            {/* Payment Methods */}
            <button
              type="button"
              onClick={() => handleSidebarNav('profile')}
              className="w-full h-9 flex items-center justify-between px-3 rounded-lg hover:bg-slate-100/80 text-slate-800 hover:text-[#0D6843] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2.5">
                <i className="ph ph-credit-card text-[17px] text-slate-500 group-hover:text-[#0D6843] transition-colors"></i>
                <span className="text-[13px] font-medium tracking-[-0.01em]">
                  {sidebarLang === 'en' ? 'Payment Methods' : 'পেমেন্ট মেথড'}
                </span>
              </div>
              <i className="ph ph-caret-right text-xs text-slate-400 group-hover:text-[#0D6843] transition"></i>
            </button>

            {/* Account Settings */}
            <button
              type="button"
              onClick={() => handleSidebarNav('profile')}
              className="w-full h-9 flex items-center justify-between px-3 rounded-lg hover:bg-slate-100/80 text-slate-800 hover:text-[#0D6843] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2.5">
                <i className="ph ph-gear text-[17px] text-slate-500 group-hover:text-[#0D6843] transition-colors"></i>
                <span className="text-[13px] font-medium tracking-[-0.01em]">
                  {sidebarLang === 'en' ? 'Account Settings' : 'অ্যাকাউন্ট সেটিংস'}
                </span>
              </div>
              <i className="ph ph-caret-right text-xs text-slate-400 group-hover:text-[#0D6843] transition"></i>
            </button>

            {/* Notifications */}
            <button
              type="button"
              onClick={() => handleSidebarNav('profile')}
              className="w-full h-9 flex items-center justify-between px-3 rounded-lg hover:bg-slate-100/80 text-slate-800 hover:text-[#0D6843] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2.5">
                <i className="ph ph-bell text-[17px] text-slate-500 group-hover:text-[#0D6843] transition-colors"></i>
                <span className="text-[13px] font-medium tracking-[-0.01em]">
                  {sidebarLang === 'en' ? 'Notifications' : 'নোটিফিকেশন'}
                </span>
              </div>
              <span className="w-5 h-5 rounded-md bg-[#0D6843] text-white text-[11px] font-semibold tabular-nums flex items-center justify-center">
                {sidebarLang === 'en' ? '3' : '৩'}
              </span>
            </button>

            {/* Help & Support */}
            <button
              type="button"
              onClick={() => handleSidebarNav('more')}
              className="w-full h-9 flex items-center justify-between px-3 rounded-lg hover:bg-slate-100/80 text-slate-800 hover:text-[#0D6843] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2.5">
                <i className="ph ph-headset text-[17px] text-slate-500 group-hover:text-[#0D6843] transition-colors"></i>
                <span className="text-[13px] font-medium tracking-[-0.01em]">
                  {sidebarLang === 'en' ? 'Help & Support' : 'সহায়তা ও সাপোর্ট'}
                </span>
              </div>
              <i className="ph ph-caret-right text-xs text-slate-400 group-hover:text-[#0D6843] transition"></i>
            </button>

            {/* About Us */}
            <button
              type="button"
              onClick={() => handleSidebarNav('more')}
              className="w-full h-9 flex items-center justify-between px-3 rounded-lg hover:bg-slate-100/80 text-slate-800 hover:text-[#0D6843] transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2.5">
                <i className="ph ph-info text-[17px] text-slate-500 group-hover:text-[#0D6843] transition-colors"></i>
                <span className="text-[13px] font-medium tracking-[-0.01em]">
                  {sidebarLang === 'en' ? 'About Us' : 'আমাদের সম্পর্কে'}
                </span>
              </div>
              <i className="ph ph-caret-right text-xs text-slate-400 group-hover:text-[#0D6843] transition"></i>
            </button>
          </nav>

          {/* Bottom Download Our App Card (8pt grid: p-3 mt-3 rounded-xl gap-3) */}
          <div className="bg-[#F6F7F9] rounded-xl p-3 flex items-center gap-3 mt-3 border border-slate-200/70 relative overflow-hidden">
            {/* Angled Phone Preview */}
            <div className="w-10 h-16 rounded-lg bg-white border-[1.5px] border-slate-800 shadow-xs -rotate-6 shrink-0 flex flex-col items-center justify-between p-1 overflow-hidden">
              <div className="w-3.5 h-0.5 bg-slate-300 rounded-full" />
              <div className="w-5 h-5 rounded-md bg-[#E8F6EF] flex items-center justify-center text-[#0D6843]">
                <i className="ph-fill ph-shopping-bag text-[10px]"></i>
              </div>
              <div className="w-full space-y-0.5">
                <div className="h-0.5 w-full bg-emerald-100 rounded-full" />
                <div className="h-0.5 w-2/3 bg-slate-100 rounded-full mx-auto" />
              </div>
            </div>

            <div className="flex-1 min-w-0">
              <h4 className="text-[13px] font-heading font-semibold text-slate-900 tracking-tight leading-snug mb-0.5">
                {sidebarLang === 'en' ? 'Download Our App' : 'আমাদের অ্যাপ ডাউনলোড করুন'}
              </h4>
              <p className="text-xs text-slate-500 font-normal leading-snug mb-2">
                {sidebarLang === 'en'
                  ? 'Extra 10% OFF on first app order'
                  : 'অ্যাপে প্রথম অর্ডারে অতিরিক্ত ১০% ছাড়'}
              </p>
              <button
                type="button"
                onClick={() => {
                  closeSidebar();
                  window.dispatchEvent(new CustomEvent('show-pwa-install'));
                }}
                className="h-7 bg-[#0D6843] hover:bg-[#094D31] transition-colors text-white text-xs font-semibold px-3 rounded-lg inline-flex items-center gap-1.5 shadow-2xs cursor-pointer"
              >
                <span>{sidebarLang === 'en' ? 'Download Now' : 'ডাউনলোড করুন'}</span>
                <i className="ph ph-arrow-right text-xs"></i>
              </button>
            </div>
          </div>
        </div>
      </aside>

      <main className="w-full max-w-full sm:max-w-[480px] mx-auto bg-white min-h-screen relative shadow-[0_0_50px_rgba(0,0,0,0.08)] ">
        
        {activeTab !== 'home' ? (
          <div className="font-sans pb-20">
            {/* Compact mobile header for non-home tab pages */}
            <header className="px-3.5 py-2.5 bg-white/95 backdrop-blur-md sticky top-0 z-40 shadow-xs border-b border-stone-200/80 mb-3">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <button onClick={openSidebar} className="p-1.5 hover:bg-stone-100 rounded-lg transition -ml-1 cursor-pointer">
                    <i className="ph ph-list text-[22px] text-stone-800 hover:text-brand-emerald transition-colors"></i>
                  </button>
                  <div className="flex items-center text-stone-900 font-heading font-semibold text-lg tracking-tight cursor-pointer">
                    <i className="ph-fill ph-tote mr-1.5 text-xl text-brand-emerald"></i> Deshi<span className="text-brand-emerald">Mart</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-stone-700 text-[20px] cursor-pointer">
                  <button onClick={onCartClick} className="relative p-1.5 hover:text-brand-emerald transition outline-none">
                    <i className="ph ph-shopping-cart"></i>
                    {cartCount > 0 && (
                      <span className="absolute top-0 right-0 bg-brand-emerald text-white text-[10px] font-semibold tabular-nums w-4 h-4 flex items-center justify-center rounded-full border border-white">{cartCount}</span>
                    )}
                  </button>
                </div>
              </div>
              
              <div 
                onClick={() => setIsLocationModalOpen(true)}
                className="flex items-center text-xs text-stone-600 mt-1.5 gap-1 cursor-pointer w-fit group"
              >
                <i className="ph-fill ph-map-pin text-brand-emerald text-xs"></i>
                <span className="group-hover:text-brand-emerald transition font-medium">ডেলিভারি: {deliveryLocation}</span>
                <i className="ph ph-caret-down ml-0.5 text-xs text-stone-400 group-hover:text-brand-emerald transition"></i>
              </div>
            </header>

            <div className="px-3.5">
              {children}
            </div>
          </div>
        ) : (
          <>
            {/* ========================================== */}
            {/* VIEW 1: FASHION & APPAREL                  */}
            {/* ========================================== */}
            <div className={`font-sans pb-20 ${activeView === 'fashion' ? '' : 'hidden'}`}>
          
          <header className="px-3.5 py-2.5 bg-white/95 backdrop-blur-md sticky top-0 z-40 border-b border-stone-200/80">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <button onClick={openSidebar} aria-label="মেনু খুলুন" className="p-1.5 hover:bg-stone-100 rounded-lg transition -ml-1">
                  <i className="ph ph-list text-[22px] text-stone-800"></i>
                </button>
                <div className="flex items-center text-stone-900 font-heading font-semibold text-lg tracking-tight cursor-pointer">
                  <i className="ph-fill ph-tote mr-1.5 text-xl text-brand-emerald"></i> Deshi<span className="text-brand-emerald">Mart</span>
                </div>
              </div>
              <div className="flex items-center gap-1.5 text-stone-700 text-[20px] cursor-pointer">
                <button onClick={() => setIsSearchOpen(!isSearchOpen)} aria-label="অনুসন্ধান" className="p-1.5 outline-none"><i className="ph ph-magnifying-glass hover:text-brand-emerald transition"></i></button>
                <button onClick={onCartClick} aria-label="কার্ট" className="relative p-1.5 hover:text-brand-emerald transition outline-none">
                  <i className="ph ph-shopping-cart"></i>
                  {cartCount > 0 && (
                    <span className="absolute top-0 right-0 bg-brand-emerald text-white text-[10px] font-semibold tabular-nums w-4 h-4 flex items-center justify-center rounded-full border border-white">{cartCount}</span>
                  )}
                </button>
              </div>
            </div>

            <div className={`overflow-hidden transition-all duration-200 ease-out ${isSearchOpen ? 'max-h-[52px] opacity-100 mt-2' : 'max-h-0 opacity-0 mt-0'}`}>
              <div className="flex rounded-xl overflow-hidden border border-stone-200 bg-stone-50 focus-within:border-brand-emerald transition-all">
                <input type="text" placeholder="আপনি কী খুঁজছেন?" className="w-full bg-transparent px-3.5 py-2 text-xs sm:text-sm outline-none font-medium" />
                <button className="bg-brand-emerald hover:bg-brand-dark text-white px-3.5 py-2 transition-colors flex items-center justify-center"><i className="ph ph-magnifying-glass text-sm"></i></button>
              </div>
            </div>

            <div 
              onClick={() => setIsLocationModalOpen(true)}
              className="flex items-center text-xs text-stone-600 mt-1.5 gap-1 cursor-pointer w-fit group"
            >
              <i className="ph-fill ph-map-pin text-brand-emerald text-xs"></i>
              <span className="group-hover:text-brand-emerald transition font-medium">ডেলিভারি করুন: {deliveryLocation}</span>
              <i className="ph ph-caret-down ml-0.5 text-xs text-stone-400 group-hover:text-brand-emerald transition"></i>
            </div>
          </header>

          <div className="space-y-1">
            <Hero currentSeason={currentSeason} />
            <CategoryList />
            <FlashSale onProductClick={onProductClick} onAddToCart={onAddToCart} />
            <Features />
            <div className="px-3.5 py-1.5">
              <div className="bg-amber-50/90 rounded-2xl p-4 flex items-center justify-between relative overflow-hidden border border-amber-200/70">
                <div className="z-10 w-2/3">
                  <p className="text-xs text-amber-800 font-semibold mb-0.5">নতুন ব্যবহারকারীদের জন্য</p>
                  <h3 className="text-xl font-heading font-bold text-amber-950 leading-tight tracking-tight">প্রথম অর্ডারে ১০% ছাড়</h3>
                  <p className="text-xs text-amber-900 font-medium mt-1 mb-2.5">চেকআউটে কোড ব্যবহার করুন</p>
                  <span className="bg-primary text-white text-xs font-semibold px-2.5 py-1.5 rounded-lg inline-flex items-center gap-1.5">
                    <i className="ph-fill ph-ticket text-xs text-amber-200"></i> কোড: NEW10
                  </span>
                </div>
                <img src="https://cdn-icons-png.flaticon.com/512/4213/4213958.png" className="w-16 h-16 object-contain z-10 drop-shadow-xs" alt="gift" />
              </div>
            </div>
            <NewArrivals onProductClick={onProductClick} onAddToCart={onAddToCart} />
            <BestSellers onProductClick={onProductClick} onAddToCart={onAddToCart} />
            <Brands />
            <CustomerReviews />
          </div>

          <TrustAndFaq />
            <Newsletter />
            <Footer />
        </div>

        {/* ============================================== */}
        {/* VIEW 2: GROCERY & FOOD                         */}
        {/* ============================================== */}
        <div className={`font-sans bg-white pb-20 ${activeView === 'grocery' ? '' : 'hidden'}`}>
          <header className="px-4 py-2.5 bg-white/95 backdrop-blur-md sticky top-0 z-40 border-b border-slate-100">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <button onClick={openSidebar} className="p-1.5 hover:bg-slate-50 rounded-lg transition -ml-1">
                  <i className="ph ph-list text-[22px] text-slate-800"></i>
                </button>
                <div className="flex items-center text-slate-900 font-heading font-semibold text-lg tracking-tight cursor-pointer">
                  <i className="ph-fill ph-shopping-bag mr-1.5 text-xl text-primary"></i> DeshiMart
                </div>
              </div>
              <div className="flex items-center gap-2 text-slate-700 text-[20px] cursor-pointer">
                <button onClick={() => setIsSearchOpen(!isSearchOpen)} className="p-1.5 outline-none hover:text-primary transition"><i className="ph ph-magnifying-glass"></i></button>
                <div className="relative p-1.5 hover:text-primary transition">
                  <i className="ph ph-bell"></i>
                  <span className="absolute top-0.5 right-0.5 bg-primary text-white text-[10px] font-semibold tabular-nums w-4 h-4 flex items-center justify-center rounded-full border border-white">3</span>
                </div>
                <button onClick={onCartClick} className="relative p-1.5 hover:text-primary transition outline-none">
                  <i className="ph ph-shopping-cart-simple"></i>
                  {cartCount > 0 && (
                    <span className="absolute top-0.5 right-0.5 bg-primary text-white text-[10px] font-semibold tabular-nums w-4 h-4 flex items-center justify-center rounded-full border border-white">{cartCount}</span>
                  )}
                </button>
              </div>
            </div>

            <div className={`overflow-hidden transition-all duration-200 ease-out ${isSearchOpen ? 'max-h-[48px] opacity-100 mt-2' : 'max-h-0 opacity-0 mt-0'}`}>
              <div className="flex gap-2">
                <div className="flex-1 h-9 rounded-lg overflow-hidden border border-slate-200 bg-slate-50/80 focus-within:border-primary/50 focus-within:bg-white transition-all flex items-center px-3">
                  <i className="ph ph-magnifying-glass text-base text-slate-400"></i>
                  <input type="text" placeholder="Search for products..." className="w-full bg-transparent px-2 text-xs sm:text-sm outline-none text-slate-700 font-medium" />
                </div>
                <button className="bg-primary hover:bg-brand-dark text-white w-9 h-9 rounded-lg transition-colors flex items-center justify-center shadow-xs">
                  <i className="ph ph-faders text-base"></i>
                </button>
              </div>
            </div>

            <div 
              onClick={() => setIsLocationModalOpen(true)}
              className="flex items-center text-xs text-stone-600 mt-1.5 gap-1 cursor-pointer w-fit group"
            >
              <i className="ph-fill ph-map-pin text-primary text-xs"></i>
              <span className="group-hover:text-primary transition font-medium">Deliver to: {deliveryLocation}</span>
              <i className="ph ph-caret-down ml-0.5 text-xs text-stone-400 group-hover:text-primary transition"></i>
            </div>
          </header>

          <section className="px-4 mt-3">
            <div className={`w-full border rounded-xl p-4 relative overflow-hidden h-[168px] shadow-xs flex items-center transition-all duration-500 ${GROCERY_SLIDES[groceryActiveSlide].bgClass}`}>
              <div className="relative z-10 w-[64%]">
                <span className={`text-xs font-semibold flex items-center gap-1 tracking-tight mb-1 ${GROCERY_SLIDES[groceryActiveSlide].badgeTextClass}`}>
                  <i className={GROCERY_SLIDES[groceryActiveSlide].badgeIconClass}></i> {GROCERY_SLIDES[groceryActiveSlide].badge}
                </span>
                <h2 className="text-lg font-heading font-semibold leading-snug tracking-tight mb-1 line-clamp-2">{GROCERY_SLIDES[groceryActiveSlide].title}</h2>
                <p className="text-xs opacity-85 mb-2.5 font-normal leading-snug w-[95%] line-clamp-2">{GROCERY_SLIDES[groceryActiveSlide].tagline}</p>
                <button className={`transition-colors text-white text-xs font-semibold px-3 py-1.5 rounded-lg shadow-xs flex items-center gap-1.5 w-fit ${GROCERY_SLIDES[groceryActiveSlide].btnClass}`}>
                  Shop Now <i className="ph ph-arrow-right text-xs"></i>
                </button>
              </div>
              <div className="absolute right-[-12px] bottom-0 h-[102%] w-[40%] flex items-end justify-end">
                <img src={GROCERY_SLIDES[groceryActiveSlide].image} className="h-full w-full object-cover rounded-bl-2xl drop-shadow-md transition-all duration-700" alt="Grocery Slide Image" />
              </div>
              
              <div className="absolute bottom-2.5 left-1/2 transform -translate-x-1/2 flex space-x-1.5 z-20">
                {GROCERY_SLIDES.map((_, idx) => (
                  <button 
                    key={idx}
                    onClick={() => setGroceryActiveSlide(idx)}
                    className={`h-1.5 rounded-full transition-all duration-300 ${groceryActiveSlide === idx ? 'w-4 bg-primary' : 'w-1.5 bg-slate-300/85'}`}
                  />
                ))}
              </div>
            </div>
          </section>

          <section className="mt-6 px-4">
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-heading font-semibold text-slate-900 text-base tracking-tight">Shop by Category</h3>
              <a href="#" className="text-primary text-xs font-semibold flex items-center gap-1">View All <i className="ph ph-caret-right"></i></a>
            </div>
            
            <div className="flex overflow-x-auto no-scrollbar gap-3 pb-2 -mx-4 px-4">
              <a href="#" className="flex flex-col items-center min-w-[68px] group">
                <div className="w-16 h-16 rounded-xl overflow-hidden relative border border-slate-100 flex items-center justify-center mb-1.5 shadow-xs bg-slate-50">
                  <img src="https://images.unsplash.com/photo-1583258292688-d0213dc5a3a8?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80" className="w-full h-full object-cover group-hover:scale-105 transition duration-300" alt="Groceries Category" />
                </div>
                <span className="text-xs font-medium text-slate-700">Groceries</span>
              </a>
              <a href="#" className="flex flex-col items-center min-w-[68px] group">
                <div className="w-16 h-16 rounded-xl overflow-hidden relative border border-slate-100 flex items-center justify-center mb-1.5 shadow-xs bg-slate-50">
                  <img src="https://images.unsplash.com/photo-1622483767028-3f66f32aef97?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80" className="w-full h-full object-cover group-hover:scale-105 transition duration-300" alt="Beverages Category" />
                </div>
                <span className="text-xs font-medium text-slate-700">Beverages</span>
              </a>
              <a href="#" className="flex flex-col items-center min-w-[68px] group">
                <div className="w-16 h-16 rounded-xl overflow-hidden relative border border-slate-100 flex items-center justify-center mb-1.5 shadow-xs bg-slate-50">
                  <img src="https://images.unsplash.com/photo-1556228578-0d85b1a4d571?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80" className="w-full h-full object-cover group-hover:scale-105 transition duration-300" alt="Personal Care Category" />
                </div>
                <span className="text-xs font-medium text-slate-700">Personal Care</span>
              </a>
              <a href="#" className="flex flex-col items-center min-w-[68px] group">
                <div className="w-16 h-16 rounded-xl overflow-hidden relative border border-slate-100 flex items-center justify-center mb-1.5 shadow-xs bg-slate-50">
                  <img src="https://images.unsplash.com/photo-1584824486509-112e4181ff6b?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80" className="w-full h-full object-cover group-hover:scale-105 transition duration-300" alt="Household Category" />
                </div>
                <span className="text-xs font-medium text-slate-700 text-center leading-tight">Household</span>
              </a>
              <a href="#" className="flex flex-col items-center min-w-[68px] group">
                <div className="w-16 h-16 rounded-xl overflow-hidden relative border border-slate-100 flex items-center justify-center mb-1.5 shadow-xs bg-slate-50">
                  <img src="https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80" className="w-full h-full object-cover group-hover:scale-105 transition duration-300" alt="Baby Care Category" />
                </div>
                <span className="text-xs font-medium text-slate-700">Baby Care</span>
              </a>
              <a href="#" className="flex flex-col items-center min-w-[68px] group">
                <div className="w-16 h-16 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center mb-1.5 group-hover:bg-slate-100 transition-colors">
                  <i className="ph ph-squares-four text-xl text-slate-600"></i>
                </div>
                <span className="text-xs font-medium text-slate-700">More</span>
              </a>
            </div>
          </section>

          <section className="mt-4 px-4">
            <div className="bg-primary rounded-xl flex overflow-hidden shadow-xs">
              <div className="w-1/2 p-3 border-r border-white/20 flex flex-col justify-center">
                <div className="text-white font-semibold text-xs sm:text-sm flex items-center gap-1">Free Delivery <i className="ph-fill ph-truck"></i></div>
                <p className="text-emerald-100 text-xs mt-0.5">On orders over ৳999</p>
              </div>
              <div className="w-1/2 p-3 bg-gradient-to-r from-primary to-brand-dark relative flex flex-col justify-center">
                <div className="text-white font-semibold text-xs sm:text-sm">Exclusive Offer!</div>
                <p className="text-emerald-100 text-xs mt-0.5">Save more with our deals</p>
                <i className="ph-fill ph-gift text-3xl absolute right-2 bottom-1 text-white/20"></i>
              </div>
            </div>
          </section>

          <section className="mt-6 px-4">
            <div className="flex justify-between items-center mb-3">
              <div className="flex items-center gap-1.5">
                <i className="ph-fill ph-lightning text-brand-orange text-lg"></i>
                <h3 className="font-heading font-semibold text-slate-900 text-base tracking-tight">Flash Sale</h3>
              </div>
              <div className="flex items-center gap-2">
                <div className="bg-brand-gold/10 text-brand-orange font-semibold tabular-nums px-2 py-0.5 rounded-md text-xs border border-brand-gold/30">02 : 45 : 30</div>
                <a href="#" className="text-primary text-xs font-semibold flex items-center gap-0.5">View All <i className="ph ph-caret-right"></i></a>
              </div>
            </div>

            <div className="flex overflow-x-auto no-scrollbar gap-3 pb-2 -mx-4 px-4">
              {isLoading ? Array(4).fill(0).map((_, i) => <GrocerySkeleton key={i} />) : [
                { img: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80', title: 'Aashirvaad Atta', qty: '5kg', price: '৳460', oldPrice: '৳599', off: '-23%' },
                { img: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80', title: 'Fresh Soyabean Oil', qty: '2L', price: '৳280', oldPrice: '৳340', off: '-18%' },
                { img: 'https://images.unsplash.com/photo-1622543925917-763c34d1a86e?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80', title: 'Tang Orange', qty: '750g', price: '৳320', oldPrice: '৳375', off: '-15%' },
                { img: 'https://images.unsplash.com/photo-1626844131082-256783844137?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80', title: 'ACI Pure Salt', qty: '1kg', price: '৳20', oldPrice: '৳25', off: '-20%' }
              ].map((item, i) => (
                <div key={i} className="min-w-[140px] border border-slate-200/80 rounded-xl bg-white p-2.5 relative flex flex-col shadow-xs hover:shadow-sm transition">
                  <div className="absolute top-2 left-2 bg-brand-orange text-white text-[10px] font-semibold px-1.5 py-0.5 rounded-md z-10">{item.off}</div>
                  <div className="h-24 w-full bg-slate-50 rounded-lg mb-2.5 flex items-center justify-center p-2">
                    <img src={item.img} className="h-full object-contain mix-blend-multiply" />
                  </div>
                  <h4 className="text-xs font-semibold text-slate-800 leading-tight mb-0.5">{item.title}</h4>
                  <span className="text-xs text-slate-500 mb-2">{item.qty}</span>
                  <div className="mt-auto flex items-end justify-between">
                    <div className="flex gap-1 items-baseline">
                      <span className="font-semibold text-slate-900 text-sm tabular-nums">{item.price}</span>
                      <span className="text-xs text-slate-400 line-through tabular-nums">{item.oldPrice}</span>
                    </div>
                    <button className="w-7 h-7 bg-primary text-white rounded-lg flex items-center justify-center hover:bg-brand-dark transition shadow-xs">
                      <i className="ph ph-shopping-cart-simple text-sm"></i>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="mt-6 px-4">
            <div className="grid grid-cols-4 gap-2 bg-slate-50 rounded-xl p-3 border border-slate-100">
              <div className="flex flex-col items-center text-center">
                <i className="ph ph-shield-check text-xl text-primary mb-1"></i>
                <span className="text-[11px] font-semibold text-slate-800">100% Original</span>
                <span className="text-[10px] text-slate-500">Authentic</span>
              </div>
              <div className="flex flex-col items-center text-center">
                <i className="ph ph-arrows-clockwise text-xl text-primary mb-1"></i>
                <span className="text-[11px] font-semibold text-slate-800">Easy Returns</span>
                <span className="text-[10px] text-slate-500">7 Days Return</span>
              </div>
              <div className="flex flex-col items-center text-center">
                <i className="ph ph-headset text-xl text-primary mb-1"></i>
                <span className="text-[11px] font-semibold text-slate-800">24/7 Support</span>
                <span className="text-[10px] text-slate-500">Service</span>
              </div>
              <div className="flex flex-col items-center text-center">
                <i className="ph ph-lock-key text-xl text-primary mb-1"></i>
                <span className="text-[11px] font-semibold text-slate-800">Secure Pay</span>
                <span className="text-[10px] text-slate-500">100% Safe</span>
              </div>
            </div>
          </section>

          <section className="mt-6 px-4">
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-heading font-semibold text-slate-900 text-base tracking-tight">Top Brands</h3>
              <a href="#" className="text-primary text-xs font-semibold flex items-center gap-1">View All <i className="ph ph-caret-right"></i></a>
            </div>
            <div className="flex overflow-x-auto no-scrollbar gap-3 pb-2 -mx-4 px-4">
              <div className="min-w-[76px] h-[84px] rounded-xl border border-slate-200/80 bg-white flex flex-col items-center justify-center gap-1.5 shadow-xs">
                <img src="https://upload.wikimedia.org/wikipedia/en/thumb/8/82/Unilever_Logo.svg/1200px-Unilever_Logo.svg.png" className="w-9 h-9 object-contain" />
                <span className="text-xs font-medium text-slate-600">Unilever</span>
              </div>
              <div className="min-w-[76px] h-[84px] rounded-xl border border-slate-200/80 bg-white flex flex-col items-center justify-center gap-1.5 shadow-xs">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Procter_%26_Gamble_logo.svg/1200px-Procter_%26_Gamble_logo.svg.png" className="w-9 h-9 object-contain" />
                <span className="text-xs font-medium text-slate-600">P&G</span>
              </div>
              <div className="min-w-[76px] h-[84px] rounded-xl border border-slate-200/80 bg-white flex flex-col items-center justify-center gap-1.5 shadow-xs">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e0/Nestl%C3%A9_logo.svg/1200px-Nestl%C3%A9_logo.svg.png" className="w-9 h-9 object-contain" />
                <span className="text-xs font-medium text-slate-600">Nestle</span>
              </div>
              <div className="min-w-[76px] h-[84px] rounded-xl border border-slate-200/80 bg-white flex flex-col items-center justify-center gap-1.5 shadow-xs">
                <h4 className="w-9 h-9 font-bold text-blue-800 text-sm flex items-center justify-center">MARCEL</h4>
                <span className="text-xs font-medium text-slate-600">Marcel</span>
              </div>
              <div className="min-w-[76px] h-[84px] rounded-xl border border-slate-200/80 bg-slate-50 flex flex-col items-center justify-center gap-1.5 shadow-xs">
                <i className="ph ph-squares-four text-xl text-slate-400"></i>
                <span className="text-xs font-medium text-slate-600">More</span>
              </div>
            </div>
          </section>

          <TrustAndFaq />
            <Newsletter />
            <Footer />
        </div>
        </>
        )}

        {/* SHARED BOTTOM NAVIGATION */}
        {activeView === 'fashion' ? (
          <nav className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-full sm:max-w-[480px] h-14 bg-white/95 backdrop-blur-md border-t border-stone-200/80 flex justify-around items-center px-2 shadow-[0_-4px_16px_rgba(0,0,0,0.04)] z-40 fashion-bottom-nav">
            <button onClick={() => onTabChange('home')} className={`flex flex-col items-center justify-center w-1/5 h-12 rounded-lg group outline-none ${activeTab === 'home' ? 'text-brand-emerald' : 'text-stone-400 hover:text-brand-emerald'}`}>
              <i className={`${activeTab === 'home' ? 'ph-fill' : 'ph'} ph-house mb-0.5 text-[18px] transition duration-200`}></i>
              <span className={`text-xs ${activeTab === 'home' ? 'font-semibold' : 'font-medium'}`}>হোম</span>
            </button>
            <button onClick={() => onTabChange('categories')} className={`flex flex-col items-center justify-center w-1/5 h-12 rounded-lg group outline-none ${activeTab === 'categories' ? 'text-brand-emerald' : 'text-stone-400 hover:text-brand-emerald'}`}>
              <i className={`${activeTab === 'categories' ? 'ph-fill' : 'ph'} ph-squares-four mb-0.5 text-[18px] transition duration-200`}></i>
              <span className={`text-xs ${activeTab === 'categories' ? 'font-semibold' : 'font-medium'}`}>ক্যাটাগরি</span>
            </button>
            <button onClick={() => onTabChange('orders')} className={`flex flex-col items-center justify-center w-1/5 h-12 rounded-lg group outline-none relative ${activeTab === 'orders' ? 'text-brand-emerald' : 'text-stone-400 hover:text-brand-emerald'}`}>
              <i className={`${activeTab === 'orders' ? 'ph-fill' : 'ph'} ph-receipt mb-0.5 text-[18px] transition duration-200`}></i>
              <span className={`text-xs ${activeTab === 'orders' ? 'font-semibold' : 'font-medium'}`}>অর্ডার</span>
            </button>
            <button onClick={() => onTabChange('profile')} className={`flex flex-col items-center justify-center w-1/5 h-12 rounded-lg group outline-none ${activeTab === 'profile' ? 'text-brand-emerald' : 'text-stone-400 hover:text-brand-emerald'}`}>
              <i className={`${activeTab === 'profile' ? 'ph-fill' : 'ph'} ph-user mb-0.5 text-[18px] transition duration-200`}></i>
              <span className={`text-xs ${activeTab === 'profile' ? 'font-semibold' : 'font-medium'}`}>প্রোফাইল</span>
            </button>
            <button onClick={() => onTabChange('more')} className={`flex flex-col items-center justify-center w-1/5 h-12 rounded-lg group outline-none ${activeTab === 'more' ? 'text-brand-emerald' : 'text-stone-400 hover:text-brand-emerald'}`}>
              <i className={`${activeTab === 'more' ? 'ph-fill' : 'ph'} ph-dots-three-circle mb-0.5 text-[18px] transition duration-200`}></i>
              <span className={`text-xs ${activeTab === 'more' ? 'font-semibold' : 'font-medium'}`}>আরও</span>
            </button>
          </nav>
        ) : (
          <nav className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-full sm:max-w-[480px] h-14 bg-white border-t border-stone-200/80 flex justify-around items-center px-2 shadow-[0_-4px_16px_rgba(0,0,0,0.04)] z-40 grocery-bottom-nav">
            <button onClick={() => onTabChange('home')} className={`flex flex-col items-center justify-center w-1/5 h-12 rounded-lg group outline-none ${activeTab === 'home' ? 'text-primary' : 'text-stone-400 hover:text-primary'}`}>
              <i className={`${activeTab === 'home' ? 'ph-fill' : 'ph'} ph-house mb-0.5 text-[18px] transition duration-200`}></i>
              <span className={`text-xs ${activeTab === 'home' ? 'font-semibold' : 'font-medium'}`}>Home</span>
            </button>
            <button onClick={() => onTabChange('categories')} className={`flex flex-col items-center justify-center w-1/5 h-12 rounded-lg group outline-none ${activeTab === 'categories' ? 'text-primary' : 'text-stone-400 hover:text-primary'}`}>
              <i className={`${activeTab === 'categories' ? 'ph-fill' : 'ph'} ph-squares-four mb-0.5 text-[18px] transition duration-200`}></i>
              <span className={`text-xs ${activeTab === 'categories' ? 'font-semibold' : 'font-medium'}`}>Categories</span>
            </button>
            <button onClick={() => onTabChange('orders')} className={`flex flex-col items-center justify-center w-1/5 h-12 rounded-lg group outline-none relative ${activeTab === 'orders' ? 'text-primary' : 'text-stone-400 hover:text-primary'}`}>
              <i className={`${activeTab === 'orders' ? 'ph-fill' : 'ph'} ph-tag mb-0.5 text-[18px] transition duration-200`}></i>
              <span className={`text-xs ${activeTab === 'orders' ? 'font-semibold' : 'font-medium'}`}>Orders</span>
            </button>
            <button onClick={() => onTabChange('profile')} className={`flex flex-col items-center justify-center w-1/5 h-12 rounded-lg group outline-none ${activeTab === 'profile' ? 'text-primary' : 'text-stone-400 hover:text-primary'}`}>
              <i className={`${activeTab === 'profile' ? 'ph-fill' : 'ph'} ph-user mb-0.5 text-[18px] transition duration-200`}></i>
              <span className={`text-xs ${activeTab === 'profile' ? 'font-semibold' : 'font-medium'}`}>Profile</span>
            </button>
            <button onClick={() => onTabChange('more')} className={`flex flex-col items-center justify-center w-1/5 h-12 rounded-lg group outline-none ${activeTab === 'more' ? 'text-primary' : 'text-stone-400 hover:text-primary'}`}>
              <i className={`${activeTab === 'more' ? 'ph-fill' : 'ph'} ph-dots-nine mb-0.5 text-[18px] transition duration-200`}></i>
              <span className={`text-xs ${activeTab === 'more' ? 'font-semibold' : 'font-medium'}`}>More</span>
            </button>
          </nav>
        )}

        {/* DELIVERY LOCATION MODAL (BOTTOM SHEET / MODAL) */}
        {isLocationModalOpen && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-[999] flex items-end sm:items-center justify-center p-0 sm:p-4 transition-opacity duration-200">
            {/* Backdrop Click */}
            <div 
              className="absolute inset-0 cursor-pointer" 
              onClick={() => {
                setIsLocationModalOpen(false);
                setLocationError(null);
              }}
            />
            
            {/* Modal Container */}
            <div className="relative bg-white w-full sm:max-w-[400px] rounded-t-2xl sm:rounded-xl shadow-2xl overflow-hidden z-10 max-h-[90vh] flex flex-col animate-slide-up sm:animate-fade-in font-bilingual">
              {/* Handle bar for bottom sheet drag visual */}
              <div className="w-10 h-1 bg-slate-200 rounded-full mx-auto my-2.5 sm:hidden shrink-0" />
              
              {/* Header */}
              <div className="px-4 py-3 border-b border-slate-100 flex justify-between items-center shrink-0">
                <div className="flex items-center gap-2">
                  <i className="ph-fill ph-map-pin text-lg text-emerald-600"></i>
                  <h3 className="text-sm sm:text-base font-heading font-semibold text-slate-900">ডেলিভারি লোকেশন পরিবর্তন করুন</h3>
                </div>
                <button 
                  onClick={() => {
                    setIsLocationModalOpen(false);
                    setLocationError(null);
                  }}
                  className="p-1.5 hover:bg-slate-50 rounded-lg transition text-slate-400 hover:text-slate-600 cursor-pointer outline-none"
                >
                  <i className="ph ph-x text-lg"></i>
                </button>
              </div>
              
              {/* Content (Scrollable) */}
              <div className="p-4 overflow-y-auto space-y-4 flex-1 max-h-[60vh] no-scrollbar">
                {/* GPS Button */}
                <button 
                  onClick={handleUseCurrentLocation}
                  disabled={isDetectingLocation}
                  className="w-full h-10 bg-emerald-50 hover:bg-emerald-100/80 active:bg-emerald-100 border border-emerald-200/60 text-emerald-800 rounded-lg px-3.5 flex items-center justify-between transition-all font-semibold text-xs sm:text-sm cursor-pointer outline-none disabled:opacity-60 disabled:cursor-not-allowed"
                >
                  <div className="flex items-center gap-2.5">
                    {isDetectingLocation ? (
                      <i className="ph ph-circle-notch text-base animate-spin text-emerald-600"></i>
                    ) : (
                      <i className="ph-fill ph-navigation-arrow text-base text-emerald-600"></i>
                    )}
                    <span>{isDetectingLocation ? 'লোকেশন অনুসন্ধান করা হচ্ছে...' : 'বর্তমান লোকেশন ব্যবহার করুন'}</span>
                  </div>
                  {!isDetectingLocation && (
                    <span className="text-[10px] bg-emerald-600 text-white font-semibold px-2 py-0.5 rounded-md uppercase tracking-wider">GPS</span>
                  )}
                </button>
                
                {locationError && (
                  <div className="bg-rose-50 border border-rose-100 text-rose-700 rounded-lg p-3 text-xs font-medium flex items-start gap-2">
                    <i className="ph-fill ph-warning-circle text-sm shrink-0 mt-0.5"></i>
                    <span>{locationError}</span>
                  </div>
                )}
                
                {/* Divider */}
                <div className="relative flex items-center justify-center py-1 shrink-0">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-slate-100"></div>
                  </div>
                  <span className="relative px-3 bg-white text-xs font-medium text-slate-400">অথবা ম্যানুয়ালি লিখুন</span>
                </div>
                
                {/* Manual Input Form */}
                <form onSubmit={handleManualLocationSubmit} className="space-y-2.5 shrink-0">
                  <div className="flex rounded-lg border border-slate-200 overflow-hidden focus-within:border-emerald-600 transition-all bg-slate-50/50 h-9 items-center px-3">
                    <i className="ph ph-map-trifold text-base text-slate-400"></i>
                    <input 
                      type="text" 
                      value={manualLocationInput}
                      onChange={(e) => setManualLocationInput(e.target.value)}
                      placeholder="আপনার থানা/এলাকা বা ঠিকানা লিখুন..." 
                      className="w-full bg-transparent px-2.5 text-xs sm:text-sm outline-none font-medium text-slate-800 placeholder-slate-400"
                    />
                  </div>
                  <button 
                    type="submit"
                    disabled={!manualLocationInput.trim()}
                    className="w-full h-9 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold px-4 rounded-lg text-xs sm:text-sm transition shadow-xs outline-none cursor-pointer"
                  >
                    আপডেট করুন
                  </button>
                </form>
                
                {/* Popular Cities */}
                <div className="shrink-0">
                  <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">জনপ্রিয় শহরসমূহ</h4>
                  <div className="grid grid-cols-4 gap-2">
                    {popularCities.map((city) => (
                      <button
                        key={city.name}
                        type="button"
                        onClick={() => selectPopularCity(city.name + ', বাংলাদেশ')}
                        className={`h-8 text-xs font-medium px-1 rounded-lg text-center border transition-all duration-200 outline-none cursor-pointer truncate ${
                          deliveryLocation.startsWith(city.name)
                            ? 'bg-emerald-600 border-emerald-600 text-white font-semibold shadow-xs'
                            : 'bg-white border-slate-200/80 hover:border-emerald-500 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50/20'
                        }`}
                      >
                        {city.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              
              {/* Current Selected Location Indicator Footer */}
              <div className="px-4 py-3 bg-slate-50 border-t border-slate-100 text-center text-xs text-slate-500 font-medium shrink-0">
                বর্তমান ঠিকানা: <span className="text-emerald-700 font-semibold">{deliveryLocation}</span>
              </div>
            </div>
          </div>
        )}

      </main>
    </div>
  );
}
