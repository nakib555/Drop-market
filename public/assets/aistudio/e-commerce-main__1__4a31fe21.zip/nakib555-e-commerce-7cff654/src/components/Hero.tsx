import React, { useState, useEffect } from 'react';
import { ChevronRight, ChevronLeft } from 'lucide-react';
import { TYPOGRAPHY_TOKENS } from '../theme';
import bannerImg from '../assets/images/eid_lifestyle_banner_1783858438483.jpg';

interface HeroProps {
  currentSeason?: string;
}

export function Hero({ currentSeason = 'default' }: HeroProps) {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const SLIDES = [
    {
      key: 'default',
      badge: 'নতুন কালেকশন ২০২৬',
      tagline: 'বাছাইকৃত খাঁটি দেশি পণ্য, ঐতিহ্যবাহী কারুশিল্প এবং প্রতিদিনের প্রিমিয়াম সম্ভার আপনার দোরগোড়ায়।',
      title: (
        <>
          প্রতিদিনের কেনাকাটায়{' '}
          <span className="text-brand-emerald dark:text-emerald-400">নির্ভরতার ছোঁয়া</span>
        </>
      ),
      background: (
        <div className="w-full h-full bg-gradient-to-br from-[#F2F6F3] via-[#FAF9F6] to-[#EFECE6] dark:from-[#111C17] dark:via-[#121315] dark:to-[#18191C]">
          <div className="absolute right-8 lg:right-20 top-1/2 -translate-y-1/2 w-64 h-64 lg:w-96 lg:h-96 rounded-full border border-brand-emerald/10 dark:border-emerald-500/10 flex items-center justify-center pointer-events-none">
            <div className="w-48 h-48 lg:w-72 lg:h-72 rounded-full border border-brand-emerald/15 dark:border-emerald-500/15 flex items-center justify-center">
              <div className="w-32 h-32 lg:w-48 lg:h-48 rounded-full bg-brand-emerald/5 dark:bg-emerald-500/5" />
            </div>
          </div>
        </div>
      ),
      kickerColor: 'text-brand-emerald dark:text-emerald-400',
      buttonClass: 'bg-brand-emerald hover:bg-brand-dark text-white',
      buttonText: 'কালেকশন দেখুন',
    },
    {
      key: 'eid',
      badge: 'ঈদ কালেকশন ২০২৬',
      tagline: 'ঐতিহ্যবাহী জামদানী, প্রিমিয়াম কটন পাঞ্জাবি এবং উৎসবের বিশেষ উপহার সামগ্রী।',
      title: (
        <>
          ঈদ হোক আনন্দময়{' '}
          <span className="text-[#9A6F28] dark:text-amber-400">ও মার্জিত</span>
        </>
      ),
      background: (
        <>
          <img 
            src={bannerImg} 
            alt="Eid Collection Banner" 
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center md:object-right transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#FAF9F6]/95 via-[#FAF9F6]/75 to-[#FAF9F6]/30 md:bg-gradient-to-r md:from-[#FAF9F6]/95 md:via-[#FAF9F6]/80 md:to-transparent dark:from-[#121315]/95 dark:via-[#121315]/80 dark:to-transparent" />
        </>
      ),
      kickerColor: 'text-[#9A6F28] dark:text-amber-400',
      buttonClass: 'bg-brand-emerald hover:bg-brand-dark text-white',
      buttonText: 'ঈদ সম্ভার দেখুন',
    },
    {
      key: 'ramadan',
      badge: 'রমজান স্পেশাল',
      tagline: 'ইফতার ও সেহরির জন্য খাঁটি সুন্দরবনের মধু, গাওয়া ঘি এবং বিশুদ্ধ অর্গানিক খাদ্যপণ্য।',
      title: (
        <>
          পবিত্র মাহে রমজানের{' '}
          <span className="text-teal-700 dark:text-teal-400">বিশুদ্ধ আয়োজন</span>
        </>
      ),
      background: (
        <div className="w-full h-full bg-gradient-to-br from-[#EFF6F5] via-[#FAF9F6] to-[#F3F1EC] dark:from-[#0F1E1E] dark:via-[#121315] dark:to-[#16181A]" />
      ),
      kickerColor: 'text-teal-700 dark:text-teal-400',
      buttonClass: 'bg-teal-700 hover:bg-teal-800 text-white',
      buttonText: 'রমজান অফার দেখুন',
    },
    {
      key: 'pohela-boishakh',
      badge: '১৪৩৩ বঙ্গাব্দ স্পেশাল',
      tagline: 'নতুন সাজে নববর্ষের প্রাণোচ্ছল বৈশাখী উৎসব এবং দেশীয় তাঁতের পোশাক কালেকশন।',
      title: (
        <>
          এসো হে বৈশাখ{' '}
          <span className="text-rose-700 dark:text-rose-400">রঙিন নববর্ষে</span>
        </>
      ),
      background: (
        <div className="w-full h-full bg-gradient-to-br from-[#FDF4F4] via-[#FAF9F6] to-[#F7F3EB] dark:from-[#211315] dark:via-[#121315] dark:to-[#181616]" />
      ),
      kickerColor: 'text-rose-700 dark:text-rose-400',
      buttonClass: 'bg-rose-700 hover:bg-rose-800 text-white',
      buttonText: 'বৈশাখী কালেকশন',
    },
    {
      key: 'winter',
      badge: 'শীতের ফ্যাশন',
      tagline: 'শীতের আমেজে আধুনিক শাল, আরামদায়ক জ্যাকেট এবং প্রাকৃতিক স্কিন কেয়ার সম্ভার।',
      title: (
        <>
          শীতের উষ্ণতা{' '}
          <span className="text-sky-700 dark:text-sky-400">নতুন আবহে</span>
        </>
      ),
      background: (
        <div className="w-full h-full bg-gradient-to-br from-[#F0F6FA] via-[#FAF9F6] to-[#F2F4F7] dark:from-[#101A24] dark:via-[#121315] dark:to-[#16181D]" />
      ),
      kickerColor: 'text-sky-700 dark:text-sky-400',
      buttonClass: 'bg-sky-700 hover:bg-sky-800 text-white',
      buttonText: 'শীতের সম্ভার দেখুন',
    }
  ];

  // Sync with currentSeason prop
  useEffect(() => {
    const matchedIndex = SLIDES.findIndex(s => s.key === currentSeason);
    if (matchedIndex !== -1) {
      setCurrentSlideIndex(matchedIndex);
    }
  }, [currentSeason]);

  // Calm editorial slide cadence (5.5 seconds, pauses on hover)
  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(() => {
      setCurrentSlideIndex(prevIndex => (prevIndex + 1) % SLIDES.length);
    }, 5500);
    return () => clearInterval(timer);
  }, [SLIDES.length, isPaused]);

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentSlideIndex(prev => (prev - 1 + SLIDES.length) % SLIDES.length);
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentSlideIndex(prev => (prev + 1) % SLIDES.length);
  };

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 md:py-4">
      <div
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
        className="relative rounded-xl overflow-hidden bg-white dark:bg-[#121316] h-[200px] sm:h-[240px] md:h-[272px] lg:h-[288px] w-full border border-stone-200/80 dark:border-neutral-800 group"
      >
        {/* Horizontal Slide Track */}
        <div 
          className="flex w-full h-full transition-transform duration-700 ease-out"
          style={{ transform: `translate3d(-${currentSlideIndex * 100}%, 0, 0)` }}
        >
          {SLIDES.map((slide) => (
            <div 
              key={slide.key} 
              className="w-full h-full shrink-0 relative overflow-hidden"
            >
              <div className="absolute inset-0 w-full h-full">
                {slide.background}
              </div>
            </div>
          ))}
        </div>

        {/* Content Overlay (8pt grid: p-4 sm:p-6 md:p-8) */}
        <div className="absolute inset-y-0 left-0 w-full md:w-[68%] lg:w-[60%] z-10 p-4 sm:p-6 md:p-8 flex flex-col justify-center pointer-events-none">
          {SLIDES.map((slide, idx) => {
            const isActive = idx === currentSlideIndex;
            return (
              <div
                key={slide.key}
                className={`absolute left-4 right-4 sm:left-6 sm:right-6 md:left-8 md:right-8 transition-all duration-500 ease-out flex flex-col justify-center pointer-events-auto ${
                  isActive 
                    ? 'opacity-100 translate-y-0' 
                    : 'opacity-0 translate-y-2 pointer-events-none'
                }`}
              >
                <div className="flex items-center gap-1.5 text-xs font-medium mb-1.5">
                  <span className={slide.kickerColor}>{slide.badge}</span>
                  <span aria-hidden="true" className="text-stone-400">·</span>
                  <span className="text-stone-500 dark:text-stone-400 font-normal">দেশিমার্ট এক্সক্লুসিভ</span>
                </div>

                <h1 className={`${TYPOGRAPHY_TOKENS.heroTitle} text-stone-900 dark:text-white mb-2 max-w-lg`}>
                  {slide.title}
                </h1>

                <p className="font-sans text-xs sm:text-sm text-stone-600 dark:text-stone-300 leading-5 mb-4 max-w-md line-clamp-2">
                  {slide.tagline}
                </p>
                
                <div className="flex flex-wrap items-center gap-2">
                  <a
                    href="#featured-collection"
                    className={`h-8 sm:h-9 px-3 sm:px-4 rounded-lg text-xs sm:text-sm font-medium transition-colors duration-150 flex items-center justify-center gap-1.5 whitespace-nowrap ${slide.buttonClass}`}
                  >
                    <span>{slide.buttonText}</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </a>
                  <a
                    href="#flash-sale"
                    className="h-8 sm:h-9 bg-white/85 dark:bg-neutral-900/85 backdrop-blur-xs text-stone-800 dark:text-stone-200 px-3 sm:px-4 rounded-lg text-xs sm:text-sm font-medium hover:bg-white dark:hover:bg-neutral-800 transition-colors border border-stone-200/90 dark:border-neutral-700 inline-flex items-center justify-center whitespace-nowrap"
                  >
                    বিশেষ অফারসমূহ
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* Slider Controls (8pt grid: w-8 h-8) */}
        <button 
          onClick={handlePrev}
          aria-label="পূর্ববর্তী স্লাইড"
          className="absolute left-3 top-1/2 -translate-y-1/2 w-8 h-8 bg-white/90 dark:bg-neutral-900/90 backdrop-blur-xs rounded-lg items-center justify-center text-stone-800 dark:text-stone-200 border border-stone-200/80 dark:border-neutral-700 opacity-0 md:group-hover:opacity-100 transition-opacity hover:bg-white hidden md:flex cursor-pointer z-20"
        >
          <ChevronLeft size={16} />
        </button>
        <button 
          onClick={handleNext}
          aria-label="পরবর্তী স্লাইড"
          className="absolute right-3 top-1/2 -translate-y-1/2 w-8 h-8 bg-white/90 dark:bg-neutral-900/90 backdrop-blur-xs rounded-lg items-center justify-center text-stone-800 dark:text-stone-200 border border-stone-200/80 dark:border-neutral-700 opacity-0 md:group-hover:opacity-100 transition-opacity hover:bg-white hidden md:flex cursor-pointer z-20"
        >
          <ChevronRight size={16} />
        </button>

        {/* Slide Indicators */}
        <div className="absolute bottom-3 left-4 sm:left-6 md:left-8 flex items-center gap-1.5 z-20">
          {SLIDES.map((slide, idx) => (
            <button
              key={slide.key}
              onClick={() => setCurrentSlideIndex(idx)}
              aria-label={`স্লাইড ${idx + 1}`}
              className={`h-1 rounded-full transition-all duration-300 cursor-pointer ${
                currentSlideIndex === idx 
                  ? 'bg-brand-emerald dark:bg-emerald-400 w-6' 
                  : 'bg-stone-300 dark:bg-neutral-700 w-1.5 hover:bg-stone-400'
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
