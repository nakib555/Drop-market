import React, { useState } from 'react';
import { Package, Clock, CheckCircle, Search, ChevronRight, ChevronDown, MapPin, CreditCard, Receipt, FileText, ShoppingBag } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface MobileOrdersProps {
  isLoggedIn?: boolean;
  onLoginClick?: () => void;
}

export function MobileOrders({ isLoggedIn = false, onLoginClick }: MobileOrdersProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null);
  const [trackId, setTrackId] = useState('#DM-1092');

  if (!isLoggedIn) {
    return (
      <div className="w-full min-h-[55vh] flex items-center justify-center py-8 px-4">
        <motion.div 
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-white dark:bg-[#121316] rounded-xl p-6 sm:p-8 border border-stone-200/80 dark:border-neutral-800 text-center max-w-sm w-full flex flex-col items-center"
        >
          <div className="w-16 h-16 rounded-full bg-brand-emerald/10 text-brand-emerald flex items-center justify-center border border-brand-emerald/20 mb-4">
            <Package size={28} className="stroke-[1.75]" />
          </div>

          <h2 className="text-lg sm:text-xl font-heading font-semibold text-stone-900 dark:text-stone-100 mb-2 tracking-tight">
            আপনার অর্ডার সমূহ
          </h2>
          
          <p className="text-xs sm:text-sm text-stone-500 dark:text-stone-400 leading-relaxed mb-6">
            আপনার অর্ডার ট্র্যাকিং করতে এবং পূর্ববর্তী সমস্ত ক্রয়ের ইতিহাস দেখতে অনুগ্রহ করে লগইন করুন।
          </p>

          <button
            onClick={onLoginClick}
            className="w-full h-9 bg-brand-emerald hover:bg-brand-dark text-white rounded-lg text-xs font-medium transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <span>লগইন করুন</span>
            <ChevronRight size={14} />
          </button>
        </motion.div>
      </div>
    );
  }

  const orders = [
    { 
      id: '#DM-1092', 
      date: 'আজ, ১০:৩০ এএম', 
      status: 'processing', 
      total: '৳ ১,২৫০', 
      itemsCount: 3,
      items: [
        { name: 'খাঁটি সুন্দরবনের মধু (৫০০ গ্রাম)', qty: 1, price: '৳ ৫৫০' },
        { name: 'প্রিমিয়াম দেশি ঘি (১ কেজি)', qty: 1, price: '৳ ৬০০' },
        { name: 'দার্জিলিং ব্ল্যাক টি', qty: 1, price: '৳ ১০০' }
      ],
      shippingAddress: 'রকিব হাসান, হাউজ ১২, রোড ৪, ধানমন্ডি, ঢাকা',
      paymentMethod: 'বিকাশ (অনলাইন পেমেন্ট)',
      subtotal: '৳ ১,২৫০',
      deliveryFee: '৳ ০ (ফ্রি)',
      grandTotal: '৳ ১,২৫০'
    },
    { 
      id: '#DM-1085', 
      date: 'গতকাল, ০৪:১৫ পিএম', 
      status: 'delivered', 
      total: '৳ ৮৯০', 
      itemsCount: 2,
      items: [
        { name: 'দেশি কালোজিরা চাল (৫ কেজি)', qty: 1, price: '৳ ৭৯০' },
        { name: 'অর্গানিক সরিষার তেল (১ লিটার)', qty: 1, price: '৳ ১০০' }
      ],
      shippingAddress: 'রকিব হাসান, হাউজ ১২, রোড ৪, ধানমন্ডি, ঢাকা',
      paymentMethod: 'ক্যাশ অন ডেলিভারি',
      subtotal: '৳ ৮৪০',
      deliveryFee: '৳ ৫০',
      grandTotal: '৳ ৮৯০'
    },
  ];

  const filteredOrders = orders.filter(order =>
    order.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleExpand = (orderId: string) => {
    setExpandedOrderId(prev => prev === orderId ? null : orderId);
  };

  return (
    <div className="w-full min-h-screen pb-8">
      {/* Header Area */}
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-3 mb-4 sm:mb-6">
        <div>
          <p className="text-xs font-medium text-brand-emerald dark:text-emerald-400 mb-0.5">অর্ডার ব্যবস্থাপনা</p>
          <h2 className="text-lg sm:text-xl font-heading font-semibold text-stone-900 dark:text-stone-100 tracking-tight">
            আমার অর্ডার সমূহ
          </h2>
          <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-400 mt-0.5">আপনার সব কেনাকাটার বিবরণ এবং শিপিং স্ট্যাটাস এখানে দেখুন</p>
        </div>
        
        {/* Search Input (h-9 = 36px) */}
        <div className="relative w-full md:w-64">
          <input 
            type="text" 
            placeholder="অর্ডার আইডি দিয়ে খুঁজুন..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-9 border border-stone-200 dark:border-neutral-700 bg-white dark:bg-[#121316] dark:text-white rounded-lg pl-9 pr-3 text-sm focus:outline-none focus:border-brand-emerald"
          />
          <Search size={14} className="absolute left-3 top-2.5 text-stone-400" />
        </div>
      </div>

      {/* Live Order Tracker Widget */}
      <div className="bg-white dark:bg-[#121316] border border-stone-200/80 dark:border-neutral-800 rounded-xl p-4 sm:p-6 mb-4 sm:mb-6">
        <div className="flex items-center gap-2 mb-3">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-emerald opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-emerald"></span>
          </span>
          <h3 className="text-sm font-semibold text-stone-900 dark:text-stone-100">লাইভ অর্ডার ট্র্যাকার</h3>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 items-stretch sm:items-center mb-4">
          <div className="flex-1 relative">
            <select
              value={trackId}
              onChange={(e) => setTrackId(e.target.value)}
              className="w-full h-9 appearance-none border border-stone-200 dark:border-neutral-800 bg-stone-50 dark:bg-neutral-900 rounded-lg pl-3 pr-8 text-xs font-medium text-stone-700 dark:text-stone-300 focus:outline-none focus:border-brand-emerald cursor-pointer"
            >
              <option value="#DM-1092">#DM-1092 (সুন্দরবনের মধু, প্রিমিয়াম ঘি...)</option>
              <option value="#DM-1085">#DM-1085 (কালোজিরা চাল, সরিষার তেল)</option>
            </select>
            <ChevronDown size={14} className="absolute right-3 top-2.5 text-stone-400 pointer-events-none" />
          </div>
          <button className="h-9 bg-brand-emerald hover:bg-brand-dark text-white px-4 rounded-lg text-xs font-medium transition-colors shrink-0">
            ট্র্যাক করুন
          </button>
        </div>

        {/* Stepper tracker */}
        {trackId && (
          <div className="relative pt-1">
            {/* Connection Line */}
            <div className="absolute left-[13px] top-[20px] bottom-[20px] w-[1.5px] bg-stone-200 dark:bg-neutral-800" />

            <div className="flex flex-col gap-4 relative z-10">
              {[
                { label: 'অর্ডার প্লেসড', desc: 'আজ, ১০:৩০ এএম', status: 'completed' },
                { label: 'প্যাকেজিং হচ্ছে', desc: 'প্রক্রিয়াধীন রয়েছে', status: trackId === '#DM-1085' ? 'completed' : 'active' },
                { label: 'কুরিয়ারে শিপড', desc: 'আজ বা আগামীকাল', status: trackId === '#DM-1085' ? 'completed' : 'pending' },
                { label: 'ডেলিভারি সম্পন্ন', desc: 'অপেক্ষমান', status: trackId === '#DM-1085' ? 'completed' : 'pending' }
              ].map((step, idx) => {
                const isCompleted = step.status === 'completed';
                const isActive = step.status === 'active';
                
                return (
                  <div key={idx} className="flex items-center gap-3 flex-1">
                    {/* Circle Indicator (w-7 h-7) */}
                    <div 
                      className={`w-7 h-7 rounded-full flex items-center justify-center border transition-all duration-300 shrink-0 ${
                        isCompleted 
                          ? 'bg-brand-emerald border-brand-emerald text-white' 
                          : isActive 
                            ? 'bg-amber-500 border-amber-500 text-white animate-pulse' 
                            : 'bg-white dark:bg-[#121316] border-stone-200 dark:border-neutral-800 text-stone-400'
                      }`}
                    >
                      {isCompleted ? (
                        <CheckCircle size={13} />
                      ) : (
                        <Clock size={13} />
                      )}
                    </div>
                    
                    <div className="text-left">
                      <div className={`text-xs font-semibold ${isCompleted ? 'text-brand-emerald' : isActive ? 'text-amber-600 dark:text-amber-400' : 'text-stone-500 dark:text-stone-400'}`}>
                        {step.label}
                      </div>
                      <div className="text-xs text-stone-400 mt-0.5">
                        {step.desc}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-3 gap-3 mb-4 sm:mb-6 tabular-nums">
        <div className="bg-white dark:bg-[#121316] border border-stone-200/80 dark:border-neutral-800 p-3 sm:p-4 rounded-xl text-center">
          <div className="text-stone-500 dark:text-stone-400 text-xs font-medium">মোট অর্ডার</div>
          <div className="text-base sm:text-xl font-semibold text-stone-900 dark:text-white mt-0.5">২ টি</div>
        </div>
        <div className="bg-white dark:bg-[#121316] border border-stone-200/80 dark:border-neutral-800 p-3 sm:p-4 rounded-xl text-center">
          <div className="text-amber-700 dark:text-amber-400 text-xs font-medium">প্রক্রিয়াধীন</div>
          <div className="text-base sm:text-xl font-semibold text-amber-700 dark:text-amber-400 mt-0.5">১ টি</div>
        </div>
        <div className="bg-white dark:bg-[#121316] border border-stone-200/80 dark:border-neutral-800 p-3 sm:p-4 rounded-xl text-center">
          <div className="text-brand-emerald dark:text-emerald-400 text-xs font-medium">ডেলিভারি সম্পন্ন</div>
          <div className="text-base sm:text-xl font-semibold text-brand-emerald dark:text-emerald-400 mt-0.5">১ টি</div>
        </div>
      </div>

      {/* Orders List */}
      {filteredOrders.length === 0 ? (
        <div className="bg-white dark:bg-[#121316] border border-stone-200/80 dark:border-neutral-800 rounded-xl p-8 text-center">
          <ShoppingBag size={36} className="text-stone-300 dark:text-stone-600 mx-auto mb-2" />
          <p className="text-stone-500 dark:text-stone-400 text-sm font-medium">কোনো অর্ডার তথ্য পাওয়া যায়নি</p>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {filteredOrders.map((order, index) => {
            const isExpanded = expandedOrderId === order.id;
            return (
              <motion.div 
                key={order.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.25, delay: index * 0.04 }}
                className="bg-white dark:bg-[#121316] border border-stone-200/80 dark:border-neutral-800 rounded-xl overflow-hidden"
              >
                {/* Main Row */}
                <div 
                  onClick={() => toggleExpand(order.id)}
                  className="p-3 sm:p-4 flex flex-wrap items-center justify-between gap-3 cursor-pointer hover:bg-stone-50/60 dark:hover:bg-neutral-900/60 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-brand-emerald/10 text-brand-emerald flex items-center justify-center shrink-0">
                      <Package size={18} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-stone-900 dark:text-stone-100 text-sm">{order.id}</span>
                        {order.status === 'processing' ? (
                          <span className="bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-400 text-xs px-2 py-0.5 rounded-md font-medium">প্রক্রিয়াধীন</span>
                        ) : (
                          <span className="bg-emerald-100 dark:bg-emerald-900/30 text-brand-emerald dark:text-emerald-400 text-xs px-2 py-0.5 rounded-md font-medium">সম্পন্ন</span>
                        )}
                      </div>
                      <span className="text-xs text-stone-400 mt-0.5 block">{order.date}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 ml-auto sm:ml-0">
                    <div className="text-right tabular-nums">
                      <span className="text-xs text-stone-400 block">{order.itemsCount} টি পণ্য</span>
                      <span className="text-sm sm:text-base font-semibold text-brand-emerald mt-0.5 block">{order.total}</span>
                    </div>
                    <div className="text-stone-400">
                      <ChevronDown size={16} className={`transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`} />
                    </div>
                  </div>
                </div>

                {/* Collapsible Details */}
                <AnimatePresence initial={false}>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: 'auto' }}
                      exit={{ height: 0 }}
                      transition={{ duration: 0.25 }}
                      className="overflow-hidden border-t border-stone-100 dark:border-neutral-800 bg-stone-50/40 dark:bg-neutral-900/30"
                    >
                      <div className="p-3 sm:p-4 space-y-4">
                        {/* Products Included */}
                        <div>
                          <h4 className="text-xs font-semibold text-stone-900 dark:text-stone-200 mb-2 flex items-center gap-1.5">
                            <Receipt size={14} className="text-brand-emerald" />
                            ক্রয়কৃত পণ্যের বিবরণ
                          </h4>
                          <div className="space-y-2">
                            {order.items.map((item, i) => (
                              <div key={i} className="flex items-center justify-between text-xs bg-white dark:bg-[#121316] p-2.5 rounded-lg border border-stone-200/70 dark:border-neutral-800">
                                <div className="font-medium text-stone-700 dark:text-stone-300 pr-3">
                                  {item.name} <span className="text-stone-400 ml-1">x{item.qty}</span>
                                </div>
                                <span className="font-semibold text-stone-900 dark:text-stone-100 shrink-0 tabular-nums">{item.price}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Shipping & Payment Grid */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <div className="bg-white dark:bg-[#121316] p-3 rounded-lg border border-stone-200/70 dark:border-neutral-800">
                            <h4 className="text-xs font-semibold text-stone-900 dark:text-stone-200 mb-1.5 flex items-center gap-1.5">
                              <MapPin size={14} className="text-brand-emerald" />
                              ডেলিভারি ঠিকানা
                            </h4>
                            <p className="text-xs text-stone-600 dark:text-stone-400 leading-relaxed">{order.shippingAddress}</p>
                          </div>
                          
                          <div className="bg-white dark:bg-[#121316] p-3 rounded-lg border border-stone-200/70 dark:border-neutral-800">
                            <h4 className="text-xs font-semibold text-stone-900 dark:text-stone-200 mb-1.5 flex items-center gap-1.5">
                              <CreditCard size={14} className="text-brand-emerald" />
                              পেমেন্ট তথ্য
                            </h4>
                            <p className="text-xs text-stone-600 dark:text-stone-400 leading-relaxed">{order.paymentMethod}</p>
                          </div>
                        </div>

                        {/* Billing Breakdown */}
                        <div className="bg-white dark:bg-[#121316] p-3 rounded-lg border border-stone-200/70 dark:border-neutral-800 max-w-sm ml-auto space-y-1.5 text-xs tabular-nums">
                          <div className="flex justify-between text-stone-500">
                            <span>সাবটোটাল</span>
                            <span>{order.subtotal}</span>
                          </div>
                          <div className="flex justify-between text-stone-500">
                            <span>ডেলিভারি ফি</span>
                            <span>{order.deliveryFee}</span>
                          </div>
                          <div className="border-t border-stone-100 dark:border-neutral-800 pt-1.5 flex justify-between font-semibold text-stone-900 dark:text-white">
                            <span>সর্বমোট</span>
                            <span className="text-brand-emerald">{order.grandTotal}</span>
                          </div>
                        </div>

                        {/* Actions Row */}
                        <div className="flex justify-end gap-2 pt-1">
                          <button className="h-8 flex items-center gap-1.5 border border-stone-200 dark:border-neutral-700 bg-white dark:bg-[#121316] hover:bg-stone-50 text-xs text-stone-700 dark:text-stone-300 px-3 rounded-lg font-medium transition-colors">
                            <FileText size={13} />
                            ইনভয়েস ডাউনলোড
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
