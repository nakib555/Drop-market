import React, { useState } from 'react';
import { categories } from '../../data';
import { ChevronRight, Search } from 'lucide-react';
import { motion } from 'motion/react';
import { Product } from '../../types';
import { TYPOGRAPHY_TOKENS } from '../../theme';

interface MobileCategoriesProps {
  onProductClick?: (product: Product) => void;
  onAddToCart?: (product: Product, quantity: number) => void;
}

export function MobileCategories({}: MobileCategoriesProps = {}) {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCategories = categories.filter(category =>
    category.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="w-full min-h-[70vh] pb-8">
      {/* Header Area */}
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-3 mb-4 sm:mb-6">
        <div>
          <p className="text-xs font-medium text-brand-emerald dark:text-emerald-400 mb-0.5">পণ্য তালিকা</p>
          <h2 className={TYPOGRAPHY_TOKENS.sectionTitle}>সকল ক্যাটাগরি</h2>
          <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-400 mt-0.5">
            দেশি মার্টের বাছাইকৃত প্রিমিয়াম ক্যাটাগরি কালেকশন
          </p>
        </div>
        
        {/* Search inside categories page (h-9 = 36px) */}
        <div className="relative w-full md:w-64">
          <input 
            type="text" 
            placeholder="ক্যাটাগরি খুঁজুন..." 
            aria-label="ক্যাটাগরি খুঁজুন"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-9 border border-stone-200 dark:border-neutral-700 bg-white dark:bg-[#121316] dark:text-white rounded-lg pl-9 pr-3 text-sm focus:outline-none focus:border-brand-emerald"
          />
          <Search size={14} className="absolute left-3 top-2.5 text-stone-400" />
        </div>
      </div>

      {filteredCategories.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-center bg-white dark:bg-[#121316] rounded-xl border border-stone-200/80 dark:border-neutral-800">
          <p className="text-stone-600 dark:text-stone-400 font-medium text-sm">কোনো ক্যাটাগরি পাওয়া যায়নি</p>
          <button 
            type="button"
            onClick={() => setSearchQuery('')}
            className="mt-2 text-brand-emerald font-medium text-xs hover:underline cursor-pointer"
          >
            সবগুলো আবার দেখান
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
          {filteredCategories.map((category, index) => (
            <motion.a 
              key={category.id} 
              href={`#cat-${category.id}`}
              onClick={(e) => e.preventDefault()}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2, delay: index * 0.02 }}
              className="group flex flex-col items-center bg-white dark:bg-[#121316] p-3 sm:p-4 rounded-xl border border-stone-200/80 dark:border-neutral-800 hover:border-brand-emerald/50 transition-all duration-200"
            >
              <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-lg overflow-hidden mb-3 bg-stone-100 dark:bg-neutral-900 border border-stone-200/60 dark:border-neutral-800">
                <img 
                  src={category.image} 
                  alt={category.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <span className="text-sm font-medium text-stone-900 dark:text-stone-100 text-center mb-1 group-hover:text-brand-emerald dark:group-hover:text-emerald-400 transition-colors">
                {category.name}
              </span>
              <div className="flex items-center text-xs font-medium text-stone-500 dark:text-stone-400 group-hover:text-brand-emerald transition-colors">
                <span>পণ্য দেখুন</span>
                <ChevronRight size={12} className="ml-0.5" />
              </div>
            </motion.a>
          ))}
        </div>
      )}
    </div>
  );
}
