/**
 * DeshiMart Compact Density Design System (8pt Grid + Small Modular Type Scale)
 * Inspired by Linear & shadcn/ui
 */

export enum SeasonMode {
  DEFAULT = 'default',
  RAMADAN = 'ramadan',
  EID = 'eid',
  BOISHAKH = 'pohela-boishakh',
  WINTER = 'winter',
}

export interface SeasonalThemeConfig {
  key: string;
  name: string;
  badgeText: string;
}

export const SEASONAL_THEMES: SeasonalThemeConfig[] = [
  { key: 'default', name: 'সাধারণ থিম', badgeText: 'নতুন কালেকশন ২০২৬' },
  { key: 'eid', name: 'ঈদ কালেকশন', badgeText: 'ঈদ কালেকশন ২০২৬' },
  { key: 'ramadan', name: 'রমজান স্পেশাল', badgeText: 'রমজান স্পেশাল' },
  { key: 'pohela-boishakh', name: 'পহেলা বৈশাখ', badgeText: '১৪৩৩ বঙ্গাব্দ স্পেশাল' },
  { key: 'winter', name: 'শীতের ফ্যাশন', badgeText: 'শীতের ফ্যাশন' },
];

export interface TypographyTokens {
  heroTitle: string;
  sectionTitle: string;
  sectionSubtitle: string;
  cardTitle: string;
  price: string;
  pricePrimary: string;
  priceSecondary: string;
  metadata: string;
}

/**
 * Small Modular Type Scale (1.125 Major Second — Linear / shadcn/ui):
 * - text-2xs: 11px / 16px
 * - text-xs:  12px / 16px
 * - text-sm:  13px / 20px
 * - text-base:14px / 20px
 * - text-lg:  16px / 24px
 * - text-xl:  18px / 24px
 * - text-2xl: 20px / 28px
 * - text-3xl: 24px / 32px
 */
export const TYPOGRAPHY_TOKENS: TypographyTokens = {
  heroTitle: 'font-editorial text-2xl sm:text-3xl lg:text-4xl font-semibold tracking-tight leading-tight',
  sectionTitle: 'font-heading text-lg sm:text-xl font-semibold tracking-tight text-stone-900 dark:text-stone-100 leading-6',
  sectionSubtitle: 'font-sans text-xs sm:text-sm text-stone-500 dark:text-stone-400 leading-5',
  cardTitle: 'font-sans text-sm font-medium text-stone-900 dark:text-stone-100 leading-5 line-clamp-2',
  price: 'font-sans text-base sm:text-lg font-semibold text-brand-emerald dark:text-emerald-400 tabular-nums tracking-tight leading-6',
  pricePrimary: 'font-sans text-base sm:text-lg font-semibold text-brand-emerald dark:text-emerald-400 tabular-nums tracking-tight leading-6',
  priceSecondary: 'font-sans text-xs text-stone-400 dark:text-stone-500 line-through tabular-nums leading-4',
  metadata: 'font-sans text-xs font-medium text-stone-500 dark:text-stone-400 leading-4',
};

/**
 * Strict 8pt Spatial Grid & Compact Surface Tokens
 * Spacing multiples: 4px (1), 8px (2), 12px (3), 16px (4), 24px (6), 32px (8)
 */
export const DESIGN_TOKENS = {
  container: 'max-w-7xl mx-auto px-4 sm:px-6 lg:px-8',
  sectionPadding: 'py-4 sm:py-6',
  cardSurface: 'bg-white dark:bg-[#121316] border border-stone-200/80 dark:border-neutral-800 rounded-lg sm:rounded-xl transition-colors duration-150',
  buttonPrimary: 'h-9 bg-brand-emerald hover:bg-brand-dark text-white font-medium text-sm rounded-lg px-4 transition-colors duration-150 inline-flex items-center justify-center gap-2',
  buttonSecondary: 'h-9 bg-stone-100 hover:bg-stone-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-stone-900 dark:text-stone-100 font-medium text-sm rounded-lg px-4 transition-colors duration-150 inline-flex items-center justify-center gap-2',
};
